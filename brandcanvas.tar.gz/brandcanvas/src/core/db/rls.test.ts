/**
 * Multi-tenant isolation proof (§12, §15: "one tenant cannot read another's data").
 *
 * This is an INTEGRATION test: it requires a live Postgres reachable at DATABASE_URL, connected as
 * the non-BYPASSRLS app role, with migrations (incl. db/policies/0001_enable_rls.sql) applied. It is
 * skipped automatically when DATABASE_URL is absent (e.g. offline CI unit stage) so the unit suite
 * stays hermetic; the CI `integration` job provisions Postgres and runs it.
 *
 * What it asserts:
 *   1. Reads are tenant-scoped: tenant A cannot see tenant B's product even with no WHERE clause.
 *   2. Writes are tenant-scoped: inserting a row whose tenant_id ≠ current tenant fails WITH CHECK.
 *   3. Unset tenant context yields zero rows (closed default), never a cross-tenant leak.
 */
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { sql } from 'drizzle-orm';
import { Pool } from 'pg';
import { getDb, withTenant } from './tenant';
import * as s from './schema';

// DATABASE_URL = app role (RLS enforced). MIGRATION_DATABASE_URL = owner role, used ONLY to
// provision tenants/plans, which the app role is deliberately not allowed to write.
const HAS_DB = !!process.env.DATABASE_URL && !!process.env.MIGRATION_DATABASE_URL;
const d = HAS_DB ? describe : describe.skip;

const TENANT_A = '00000000-0000-4000-8000-00000000000a';
const TENANT_B = '00000000-0000-4000-8000-00000000000b';

d('RLS tenant isolation', () => {
  let owner: Pool;

  beforeAll(async () => {
    owner = new Pool({ connectionString: process.env.MIGRATION_DATABASE_URL });
    await owner.query(
      `insert into plans (key, label, rank) values ('free','Free',0) on conflict do nothing`,
    );
    await owner.query(
      `insert into tenants (id, slug, name, plan_key) values
         ($1,'tenant-a','A','free'), ($2,'tenant-b','B','free')
       on conflict do nothing`,
      [TENANT_A, TENANT_B],
    );

    // Tenant rows are written AS THE APP ROLE through withTenant — this also exercises WITH CHECK.

    await withTenant(TENANT_A, async (tx) => {
      await tx
        .insert(s.products)
        .values({ tenantId: TENANT_A, name: 'A-only widget', category: 'Apparel', breaks: [] })
        .onConflictDoNothing();
    });
    await withTenant(TENANT_B, async (tx) => {
      await tx
        .insert(s.products)
        .values({ tenantId: TENANT_B, name: 'B-only widget', category: 'Apparel', breaks: [] })
        .onConflictDoNothing();
    });
  });

  afterAll(async () => {
    await owner?.end();
  });

  it('app role cannot provision tenants (write to global tables is denied)', async () => {
    const db = getDb();
    await expect(
      db.execute(sql`insert into tenants (slug, name) values ('rogue', 'Rogue')`),
    ).rejects.toThrow();
  });

  it('A cannot read B rows even with an unfiltered select', async () => {
    const rowsSeenByA = await withTenant(TENANT_A, async (tx) => {
      return tx.select({ name: s.products.name }).from(s.products);
    });
    const names = rowsSeenByA.map((r) => r.name);
    expect(names).toContain('A-only widget');
    expect(names).not.toContain('B-only widget');
  });

  it('B cannot read A rows even with an unfiltered select', async () => {
    const rowsSeenByB = await withTenant(TENANT_B, async (tx) => {
      return tx.select({ name: s.products.name }).from(s.products);
    });
    const names = rowsSeenByB.map((r) => r.name);
    expect(names).toContain('B-only widget');
    expect(names).not.toContain('A-only widget');
  });

  it('rejects inserting a row for a different tenant (WITH CHECK)', async () => {
    await expect(
      withTenant(TENANT_A, async (tx) => {
        await tx
          .insert(s.products)
          .values({ tenantId: TENANT_B, name: 'smuggled', category: 'Apparel', breaks: [] });
      }),
    ).rejects.toThrow();
  });

  it('with no tenant context set, tenant tables return zero rows (closed default)', async () => {
    const db = getDb();
    const rows = await db.execute(sql`select count(*)::int as n from products`);
    // `db` handle has no app.current_tenant_id set → policy denies all rows.
    const n = (rows.rows?.[0] as { n: number } | undefined)?.n ?? 0;
    expect(n).toBe(0);
  });
});
