/**
 * Absolute admin URLs for emails (ADR 0008). Built from configuration only: the request's Host
 * header is attacker-controlled, and a sign-in link built from it could point at their server.
 *
 * - PUBLIC_BASE_URL set (dev, or a path-mode deploy) → `${base}/t/<slug>/admin/…`
 * - otherwise the tenant's own host: its custom domain while entitled, else `<slug>.<BASE_DOMAIN>`.
 */
import type { TenantContext } from '@/server/tenancy/context';

export function makeAdminUrl(opts: { publicBaseUrl?: string; baseDomain: string }) {
  const base = opts.publicBaseUrl?.replace(/\/+$/, '');
  return (ctx: TenantContext, path: string): string => {
    if (base) return `${base}/t/${encodeURIComponent(ctx.tenant.slug)}${path}`;
    const host = ctx.tenant.customDomain && ctx.can('custom_domain') ? ctx.tenant.customDomain : `${ctx.tenant.slug}.${opts.baseDomain}`;
    return `https://${host}${path}`;
  };
}
