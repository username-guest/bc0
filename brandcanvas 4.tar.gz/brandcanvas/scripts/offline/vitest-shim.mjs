/** Minimal describe/it/expect subset — enough for the pure-logic suites. Real CI uses vitest. */
import { isDeepStrictEqual } from 'node:util';

/** Vitest's toMatchObject: objects match partially (recursively); arrays match element-wise, same length. */
function subset(a, e) {
  if (Array.isArray(e)) return Array.isArray(a) && a.length === e.length && e.every((v, i) => subset(a[i], v));
  if (e && typeof e === 'object' && !(e instanceof Date) && !(e instanceof RegExp)) {
    return !!a && typeof a === 'object' && Object.entries(e).every(([k, v]) => subset(a[k], v));
  }
  return isDeepStrictEqual(a, e);
}
const tests = [];
const stack = [];
export const describe = (name, fn) => { stack.push(name); fn(); stack.pop(); };
describe.skip = (name) => { tests.push({ name: `${name} (skipped)`, skip: true }); };
export const it = (name, fn) => tests.push({ name: [...stack, name].join(' › '), fn });
export const test = it;
export const beforeAll = (fn) => tests.push({ name: '(beforeAll)', fn, hook: true });
export const afterAll = () => {};
function fail(msg) { throw new Error(msg); }
const show = (v) => { try { return JSON.stringify(v); } catch { return String(v); } };
export function expect(actual) {
  const m = {
    toBe: (e) => Object.is(actual, e) || fail(`expected ${show(actual)} to be ${show(e)}`),
    toEqual: (e) => isDeepStrictEqual(actual, e) || fail(`expected ${show(actual)} to equal ${show(e)}`),
    toStrictEqual: (e) => isDeepStrictEqual(actual, e) || fail(`expected ${show(actual)} to equal ${show(e)}`),
    toBeGreaterThan: (e) => actual > e || fail(`expected ${actual} > ${e}`),
    toBeGreaterThanOrEqual: (e) => actual >= e || fail(`expected ${actual} >= ${e}`),
    toBeLessThan: (e) => actual < e || fail(`expected ${actual} < ${e}`),
    toBeLessThanOrEqual: (e) => actual <= e || fail(`expected ${actual} <= ${e}`),
    toBeCloseTo: (e, d = 2) => Math.abs(actual - e) < 10 ** -d / 2 || fail(`expected ${actual} ≈ ${e}`),
    toContain: (e) => actual.includes(e) || fail(`expected ${show(actual)} to contain ${show(e)}`),
    toHaveLength: (n) => actual.length === n || fail(`expected length ${n}, got ${actual.length}`),
    toBeTruthy: () => !!actual || fail(`expected truthy, got ${show(actual)}`),
    toBeFalsy: () => !actual || fail(`expected falsy, got ${show(actual)}`),
    toBeDefined: () => actual !== undefined || fail('expected defined'),
    toBeUndefined: () => actual === undefined || fail(`expected undefined, got ${show(actual)}`),
    toBeNull: () => actual === null || fail(`expected null, got ${show(actual)}`),
    toMatch: (re) => (typeof re === 'string' ? actual.includes(re) : re.test(actual)) || fail(`expected ${show(actual)} to match ${re}`),
    toMatchObject: (e) => subset(actual, e) || fail(`expected ${show(actual)} to match ${show(e)}`),
    toThrow: (re) => {
      try { actual(); } catch (err) { if (re && !String(err?.message).match(re)) fail(`threw ${err.message}, expected ${re}`); return; }
      fail('expected function to throw');
    },
  };
  m.not = Object.fromEntries(Object.entries(m).map(([k, f]) => [k, (...a) => {
    let passed = true; try { f(...a); } catch { passed = false; }
    if (passed) fail(`expected NOT ${k}(${a.map(show).join(', ')}) — actual ${show(actual)}`);
  }]));
  m.rejects = { toThrow: async () => { try { await actual; } catch { return; } fail('expected promise to reject'); } };
  return m;
}
export async function run(label) {
  let pass = 0, failN = 0, skip = 0;
  for (const t of tests) {
    if (t.skip) { skip++; continue; }
    try { await t.fn(); if (!t.hook) pass++; }
    catch (e) { failN++; console.log(`  ✗ ${t.name}\n      ${e.message}`); }
  }
  console.log(`${failN ? '✗' : '✓'} ${label}: ${pass} passed${failN ? `, ${failN} FAILED` : ''}${skip ? `, ${skip} skipped` : ''}`);
  tests.length = 0;
  return failN;
}
