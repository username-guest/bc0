# BrandCanvas

Multi-tenant, white-label lead-generation tool for promotional-products distributors.
A prospect uploads a logo, sees it rendered on real promo products, browses a dynamic
catalog with live **estimated** pricing, and converts into a lead.

> **Build status:** foundation phase. See `docs/BUILD-PLAN.md` for exactly what is built,
> what is stubbed behind an interface, and what is not yet started. This is **not** a
> finished product — it is a correct, phased foundation with two fully-implemented and
> tested logic cores (pricing, feature flags) and the architectural seams for the rest.

## See it
`npm run demo` (no install needed, Node ≥ 22.18) writes `demo/index.html`: logo upload → cleanup →
Brand-Exact proofs → priced, faceted catalog with a quantity switcher → every decoration method.

## What actually works right now
- **Core loop, headless** (`src/imaging`, `src/features`): logo intake and cleanup, colour
  counting, deterministic Brand-Exact proofs for all 9 methods, and a priced, faceted catalog.
- **Pricing engine** (`src/pricing`): all 9 decoration methods modelled per industry
  conventions, itemized breakdown, admin-configurable rules, unit-tested. All rate tables
  are labelled `PLACEHOLDER` and every quote is flagged `estimated` with a disclaimer.
- **Feature-flag + entitlement evaluator** (`src/flags`): server-authoritative, correct
  precedence chain (kill-switch → plan → tenant → user → default), unit-tested.
- **Provider abstractions** (`src/shared/providers`): the upgrade seam. Every external
  capability (image gen, bg removal, storage, product data, pricing, CRM, vision) is an
  interface with a working mock, so the app runs without any external service wired.
- **Tenancy + RLS model** (`src/core/db`): Postgres row-level security, `tenant_id` on every
  domain row, `withTenant()` transaction wrapper, and an isolation test (see caveat below).
- **Multi-tenant storefront** (`src/server`, `src/ui`, `src/app`): subdomain / path / custom-domain
  routing, per-request server-side entitlements, logo upload (PNG/JPEG/WebP/SVG), cached proofs,
  priced faceted catalog, white-label branding — driven end to end in a real browser.
- **Lead capture** (`src/features/leads`, `src/server/http/leads-api.ts`, `src/ui/LeadForms.tsx`):
  email gate (Free), server-priced quote requests (Starter), branded PDF leave-behind (Pro), and
  signed webhook routing to the tenant's CRM (Pro). Leads are stored before routing, so a CRM
  outage never loses one.
- **Tenant admin** (`src/server/http/admin-api.ts`, `src/ui/admin`, `/t/<slug>/admin`): passwordless
  sign-in by emailed link, a lead inbox with CSV export and manual CRM retries, and settings for
  storefront look, email gate and where leads go. Failed CRM deliveries retry automatically; the
  webhook guard checks resolved addresses at connect time and secrets are encrypted at rest.
- **Pricing admin** (`src/pricing/config-validation.ts`, `src/ui/admin/PricingPanel.tsx`): each
  distributor sets its own markups, fees and decoration rates for all 9 methods, with a live preview
  of every product's price before saving. Prospects see selling prices only, never cost or margin.
- **Decision records** (`docs/adr`): stack, tenancy/RLS, flags, image provider, renderer, app shell,
  lead capture, tenant admin, pricing admin.

## What is stubbed or not yet built
See `docs/BUILD-PLAN.md`. In short: analytics and tracked links, queue-based
pre-rendering, the S3 adapter, teammate invites and the Enterprise adapters (PromoStandards /
Salesforce / SSO / API) are interface-level or pending.

## Setup
Two database roles, on purpose:
- `MIGRATION_DATABASE_URL` — owner role. Runs migrations, RLS policies, seed. Never used by the app.
- `DATABASE_URL` — `brandcanvas_app`, non-superuser, no BYPASSRLS. The only role the app uses.

```bash
cp .env.example .env        # set both URLs. Providers default to mocks.
npm install
npm run db:setup            # generate → migrate → apply RLS policies → seed (all as owner)
# once, per environment: give the app role a login
psql "$MIGRATION_DATABASE_URL" -c "ALTER ROLE brandcanvas_app LOGIN PASSWORD '...';"
npm run test                # unit; RLS isolation test runs when both URLs are set
```
`npm run dev` serves the storefront at `http://localhost:3000/t/demo` (Free plan: `/t/basic`) and
the admin at `/t/demo/admin` (Leads, Pricing and Settings tabs). In memory mode, sign in as `owner@demo.test` (or `staff@demo.test`,
`owner@basic.test`): with `EMAIL_PROVIDER=log` the sign-in link is printed to the server console.
With Postgres, grant access with `npm run admin:add -- demo you@company.com tenant_owner`.

Production needs, beyond the database URLs: `AUTH_SECRET`, `SETTINGS_ENCRYPTION_KEYS`
(`id:$(openssl rand -base64 32)`), `EMAIL_PROVIDER=resend` + `RESEND_API_KEY`, and `TRUST_PROXY=true`
behind your proxy (otherwise every client shares one rate-limit bucket).
With `DATA_MODE=memory` (the default) no database is needed. `npm run dev:api` runs the same tenant
API with zero dependencies installed.

## Scripts
| Script            | Purpose                                            |
|-------------------|----------------------------------------------------|
| `npm run dev`     | Next.js dev server                                 |
| `npm run typecheck` | `tsc --noEmit` (strict)                          |
| `npm run lint`    | ESLint                                             |
| `npm run test`    | Vitest (unit + integration)                        |
| `npm run db:setup` | generate + migrate + RLS policies + seed (owner role) |
| `npm run test:offline` | Pure suites via Node's native TS — no `npm install` needed |
| `npm run demo` | Build the core-loop demo page from the real modules |
| `npm run dev:api` | Tenant API over node:http, no install needed (host-based tenant routing) |
| `npm run typecheck:offline` | Strict tsc with stubs only for uninstalled packages |
| `npm run smoke:http` | Tenant API over real sockets: routing, isolation, gates |
| `npm run e2e:browser` | Real storefront UI in headless Chromium against the real API |
| `npm run e2e:admin` | Real admin UI in headless Chromium: sign-in, inbox, settings, webhook |
| `npm run admin:add` | Grant a person admin access to a tenant (Postgres) |
| `npm run jobs:deliveries` | One pass of CRM delivery retries (for cron, with `DELIVERY_WORKER=off`) |
| `npm run verify:pricing` | Dependency-free arithmetic check of the pricing engine (runs without `npm install`) |

## Honesty / guardrails (from the spec, enforced here)
- **No real supplier pricing exists.** Every number is a `PLACEHOLDER` and every quote is
  labelled *estimated* with a disclaimer. Real data arrives later via `PricingProvider` /
  `ProductDataProvider` (PromoStandards adapter seam).
- **No image is silently shipped at low confidence.** `VisionAnalyzer` returns a confidence;
  below threshold the pipeline is designed to force manual zone placement (Stage D).
- **Entitlement is never trusted from the client.** `useFeature()` only gates presentation.

## Verification
See `docs/BUILD-PLAN.md` → *Verification status*. In short: strict type-check, 174 unit tests,
12 real-socket checks and 64 headless-browser checks (26 storefront, 38 admin) were all executed. What was NOT run in the
authoring sandbox: the Next.js build itself, Postgres (RLS + Drizzle repos) and the real
`npm run typecheck` over DB modules — CI runs those.

Without a local install, point the offline scripts at another node_modules (e.g. a global one):
`BC_EXTRA_MODULES=/path/to/node_modules npm run e2e:browser`.
