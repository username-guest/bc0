# Build plan & status (§14 phases)

Legend: [x] done  ·  [~] partial / interface + mock only  ·  [ ] not started

## Phase 1 — Foundation
- [x] Repo structure, module boundaries, TS strict config, ESLint/Prettier
- [x] zod-validated env (`src/core/config/env.ts`), `.env.example`
- [x] CI pipeline (`.github/workflows/ci.yml`: lint → typecheck → test → build)
- [~] DB schema (18 of the §10 entities incl. all reference tables; the rest follow the same shape)
- [x] Migration flow: drizzle-kit generate/migrate + separate RLS policy file, owner vs app roles
- [x] Tenancy + RLS (ENABLE+FORCE, closed default) + `withTenant()` + isolation test (CI job runs it as the app role)
- [x] Idempotent seed: plans, all flags, 15 colour families, 9 methods, demo tenant, 6-product catalog
- [x] Domain modules: decoration-method registry + compatibility rules, colour-family classifier (tested)
- [x] Staff auth: first-party magic-link sign-in, server-side sessions, CSRF, roles (ADR 0008,
  supersedes the Auth.js choice in ADR 0001)

## Phase 2 — Flags & entitlements
- [x] Typed registry + evaluator + precedence chain + entitlement map + tests
- [ ] Admin toggle UI

## Phase 3 — Logo intake + cleanup + colour extraction
- [x] Intake service: magic-byte sniffing, size limits, SVG safety screen, typed errors, sha256 hash
- [x] Local PNG codec (all colour types/depths, palette+tRNS, CRC-checked, bomb guard)
- [x] Background removal (uniform bg, soft edges, colour decontamination, enclosed-area reporting)
- [x] Palette extraction in Lab space — AA-aware spot-colour count; photographic detection
- [x] `sharp` ImageCodec (JPEG/WebP/SVG tested with real sharp; PDF wired but untested)
- [x] Persistence: logo_assets (Drizzle) + StorageProvider (local FS with traversal-proof keys); upload dedupe by hash

## Phase 4 — Vision detection + mockup pipeline
- [x] Brand-Exact renderer: all 9 methods with physical constraints + legibility notes (ADR 0005)
- [x] Product templates (6 kinds), colourways, authored zones; confidence gate → needs_placement
- [x] Deterministic proofs + content-addressed cache key (renderer-versioned)
- [~] `VisionAnalyzer` + AI Lifestyle `ImageGenerationProvider`: interfaces + mocks only
- [x] Proof cache persisted in storage (content-addressed, ETag/304), render rate limit on cache misses
- [x] Template warm-up at server start (removes ~1.5 s cold cost from the first proof)
- [ ] pg-boss orchestration for catalog-wide pre-rendering, quotas, cancellation

## Phase 5 — Catalog + faceted search + qty/price-break UI
- [x] Catalog service: compatibility ∩ entitlement ∩ logo suitability, cheapest-method pick,
      distinct alternatives, price-break preview, correct faceted counts
- [x] Offline demo page (`npm run demo`) showing the full core loop from the real modules
- [x] Tenant API: upload, cleaned-logo image, catalog, proofs, public config (ADR 0006)
- [x] Storefront UI (`src/ui`): upload + knockout question, quantity, facets, proof cards with
      renderer notes, price breaks, breakdown; mobile layout; driven in headless Chromium
- [~] Next.js mounting (middleware, layouts, catch-all route): thin, written, not yet built here

## Phase 6 — Pricing engine + admin config
- [x] Engine, per-method modules, itemized breakdown, tests, verified arithmetic
- [x] Per-tenant decoration rates for all 9 methods (were a global constant); placeholder fallback
- [x] Pricing admin (ADR 0009): markups (blank, decoration, per category), fees, rounding, breakdown
  visibility, rate tables incl. screen-print tiers; strict validation by field path; warnings
- [x] Live preview: every product at a sample order with unsaved values, beside current prices
- [x] Owner-only save, staff read-only, Starter plan gate, audited with a readable change summary
- [x] Bug fix: prospects were shown blank cost and margin; now selling prices only (`prospectLines`)
  and the "show breakdown" setting is honoured
- [ ] Multi-currency

## Phase 7 — Lead capture (3 paths) + routing
- [x] Anonymous prospect sessions: HMAC-signed cookie, tenant-scoped, 30-day TTL
- [x] Email gate (Free): off / soft / hard modes with a free-proof allowance, enforced server-side
- [x] Quote request (Starter): server re-prices every quote; client prices ignored
- [x] PDF leave-behind (Pro): dependency-free PDF writer, branded, with proofs and price breaks
- [x] Leads stored before routing; `routed` / `routing_failed` events; dedup on lower-cased email
- [x] Explicit, versioned, upgrade-only marketing consent; honeypot + timing bot screen
- [x] Signed webhook CRM routing (Pro) with https-only, host-pattern SSRF block, no redirects, 5 s timeout
- [x] "Keep as printed ink" persisted via `POST /logos/:id/confirm`
- [x] Retry job for failed deliveries; connect-time SSRF check; encrypted webhook secrets (ADR 0008)

## Phase 8 — PDF export + tracked links + analytics
- [~] PDF leave-behind built in Phase 7; tracked links and analytics pending
## Phase 9 — White-label branding + custom domain (flagged)
- [x] Subdomain, `/t/:slug` and custom-domain resolution; host-bound API rule (planRouting)
- [x] Branding as CSS variables with WCAG-chosen button ink; platform defaults below Starter
- [x] Custom domains served only while entitled
- [x] Branding admin UI (name, colours, font; Starter and above)
- [ ] Custom-domain verification (DNS/TLS)
## Tenant admin (ADR 0008)
- [x] Magic-link sign-in: 256-bit single-use tokens in the URL fragment, 15-min expiry, links from
  config (not Host), no account enumeration, per-address cap; `npm run admin:add`, `SEED_ADMIN_EMAIL`
- [x] Sessions: hashed, tenant-scoped, revocable, 12 h; CSRF header on mutations; cross-site refused
- [x] Roles: owner vs admin (only owners change where leads go)
- [x] Lead inbox: keyset paging, search, source filter, "needs attention", detail timeline,
  manual retry, CSV export with formula defusing
- [x] Settings: storefront look, email gate, where leads go (secret shown once, "Send a test")
- [x] Audit log for sign-ins, exports, retries and settings; last ten shown with who did them
- [x] Delivery outbox: one row per capture, backoff 1 m → 12 h, dead-lettering, leased claims
  (`SKIP LOCKED`), stable `deliveryId`; in-process worker or `npm run jobs:deliveries`
- [x] Bug fixes: webhook entitlement never checked; untrusted `X-Real-IP` used for rate limits
- [ ] Invite teammates from the UI; sweep of expired tokens/sessions; Resend verified live
## Phase 10 — Enterprise adapters (PromoStandards / Salesforce / SSO / API), stubbed behind interfaces    [~ seams only]
## Phase 11 — Hardening: coverage, security, a11y, docs + ADRs
- [x] ADRs 0001–0009; mutation checks on isolation, entitlement, lead-capture, delivery and admin tests
- [~] a11y basics (focus rings, labels, reduced motion, 44px targets); no audit yet
- [ ] Shared-store rate limiter for multi-instance deploys

## Verification status (all executed in the authoring sandbox)
- `npm run typecheck:offline`: strict `tsc` over all app code, scripts and UI (real Playwright/esbuild
  types; only the Drizzle/zod modules are stubbed — those are checked by `npm run typecheck` in CI).
  Caught real errors: `Uint8Array` response bodies under TS ≥ 5.7, TS 6 side-effect CSS imports,
  deprecated `baseUrl`.
- `npm run test:offline`: 174 tests across 13 suites, incl. real sharp decoding (the 4 sharp tests
  skip unless sharp is installed or `BC_EXTRA_MODULES` points at it; the RLS isolation suite needs
  Postgres and runs in CI). Mutation-checked: removing the tenant scope from the logo repo or the
  custom-domain entitlement guard fails tests, as do seven security mutations in lead capture, six
  in delivery (entitlement, DNS answers, leases, tenant-bound secrets, dead-lettering, delivery id)
  and ten in admin (CSRF, owner role, plan gate, token reuse/expiry/tenant, Host-header links, CSV
  injection, enumeration, sign-out revocation), and thirteen in pricing (owner-only save, plan gate,
  raw-input storage, fractional cents, tier order, currency, tenant rates, disclaimer, and four ways
  cost or margin could leak to prospects, plus rounded unit labels).
- `npm run smoke:http`: 12 checks over real sockets — upload, catalog, proof cache/ETag,
  subdomain + custom-domain routing, cross-tenant API denial, Free-plan 403.
- `npm run e2e:browser`: 26 checks driving the real React UI in headless Chromium against the real
  API — incl. a JPEG upload, the knockout question, the hard email gate, all 6 proofs, re-pricing,
  filtering, a server-priced quote, the PDF leave-behind downloaded and rendered by pdf.js, mobile
  layout, Free-plan gating, zero console errors. It caught a hidden largest quantity on 390px screens.
- `npm run e2e:admin`: 38 checks with the real admin UI and API in headless Chromium: sign-in via
  the emailed link, inbox, search, detail, settings reaching the storefront, a real webhook receiver
  (signed ping), a failed delivery retried by hand, CSV download, owner vs staff, Free plan, mobile.
  Screenshot review caught inbox-only leads stamped "Sent to CRM" and a clipped mobile list.
  Pricing adds: live preview, margin equivalent, field errors, prospect-safe breakdown, save reaching
  the storefront, staff read-only, Free plan, mobile. Screenshot review caught a 25 px mobile overflow
  the old check had missed (mobile emulation widens the viewport to fit); both suites now measure
  against the device width and name the culprits.
- `npm run demo`: static core-loop page from the real modules.

## Known gaps
- Next.js itself isn't installed in the sandbox: middleware/layout/route mounting are unbuilt here.
  CI `unit` runs the real `typecheck` + `build`.
- Drizzle repos + RLS isolation need Postgres: CI `integration` job. Generated migrations aren't
  committed — run `npm run db:generate` once and commit `drizzle/`.
- S3 storage adapter pending; PDF logo decoding untested.
- Postgres repos for sessions, leads, deliveries and admin auth are written but only the in-memory
  repos are exercised here (new tables: `lead_deliveries`, `admin_login_tokens`, `admin_sessions`,
  `tenant_branding.display_name`, unique `users(tenant_id, email)`); CI `integration` covers Postgres.
- Resend email adapter checked for request shape only, not against the live service.
- Rate limiter (incl. sign-in caps) is per process; multi-instance deploys need a shared store.
- No in-app teammate invites; no sweep of expired login tokens/sessions yet.

## Recommended next phase
Run the unverified pieces for real before building more: `npm install`, `npm run build`,
`npm run db:generate` (commit `drizzle/`), and the CI integration job against Postgres. Four new
tables, a new column and a unique index have landed since the last database run, plus the pricing
upsert. Then production readiness: S3 storage, a shared rate-limit store, a sweep of expired
sign-in tokens and sessions, and in-app teammate invites.
