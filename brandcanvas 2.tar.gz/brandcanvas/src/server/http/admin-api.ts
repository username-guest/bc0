/**
 * Tenant admin API (ADR 0008), mounted at /api/t/<ref>/admin/…
 *
 *   POST sign-in                 {email}          → 202 always (no account enumeration)
 *   POST verify                  {token}          → session cookie
 *   POST sign-out                                 → revoke
 *   GET  me                                       → user, role, CSRF token, entitlements
 *   GET  leads?search&source&attention&cursor     → inbox page
 *   GET  leads/<id>                               → lead + events + deliveries
 *   GET  leads.csv                                → export
 *   POST deliveries/<id>/retry                    → manual retry of a failed/dead delivery
 *   GET  settings                                 → branding, gate, routing (secret never returned)
 *   PUT  settings/branding | settings/gate | settings/routing
 *   POST settings/routing/test                    → signed ping to the webhook
 *
 * Every response is no-store. Mutations need the CSRF header; cross-site requests are refused.
 * Entitlements are checked here, server-side, exactly as on the storefront.
 */
import type { TenantContext } from '@/server/tenancy/context';
import type { EmailProvider } from '@/shared/providers';
import type { RateLimiter } from '@/server/rate-limit';
import type { DeliveryBrief, DeliveryRepo, LeadRecord, LeadRepo, LeadSource, ProductRepo } from '@/server/repos/types';
import type { TenantPricingConfig } from '@/pricing/types';
import { validatePricingConfig } from '@/pricing/config-validation';
import { PLACEHOLDER_RATES, PLACEHOLDER_TENANT_CONFIG, resolveRates } from '@/pricing/placeholder-rates';
import { disclaimerFor, prospectLines } from '@/pricing/engine';
import { searchCatalog } from '@/features/catalog/catalog';
import { DECORATION_METHODS } from '@/core/domain/decoration-methods';
import type { DeliveryService } from '@/server/leads/delivery';
import type { SecretBox } from '@/server/crypto/secret-box';
import type { AdminAuthStore, AdminSession, AdminUser, AuditRepo, TenantSettingsWriter } from '@/server/admin/types';
import { DEFAULT_LEAD_SETTINGS, normalizeEmail, type GateMode, type LeadSettings } from '@/features/leads/rules';
import { WebhookCrmProvider, webhookUrlProblem, type WebhookOptions } from '@/shared/providers/webhook-crm';
import {
  ADMIN_SESSION_TTL_MS,
  LOGIN_TOKEN_TTL_MS,
  adminCookieHeader,
  adminCookieName,
  hashSecret,
  isCrossSite,
  isSecretShape,
  newSecret,
  readCookie,
  safeEqual,
} from '@/server/admin/auth';
import { HEX, UUID, clientIp, fail, jsonResponse, limited, locked, readJsonObject } from './shared';

export interface AdminDeps {
  auth: AdminAuthStore;
  settings: TenantSettingsWriter;
  audit: AuditRepo;
  email: EmailProvider;
  leads: LeadRepo;
  products: ProductRepo;
  deliveries: DeliveryRepo;
  delivery: DeliveryService;
  secrets: SecretBox;
  limits: { signIn: RateLimiter; signInEmail: RateLimiter };
  /** Absolute URL of an admin page for this tenant, from CONFIG — never from the Host header. */
  adminUrl: (ctx: TenantContext, path: string) => string;
  secureCookies: boolean;
  trustProxy: boolean;
  webhook?: Pick<WebhookOptions, 'allowInsecure' | 'resolver'>;
  now: () => Date;
  newId: () => string;
  log?: (msg: string) => void;
}

const FONTS = ['Inter', 'Georgia', 'Helvetica', 'Arial', 'Verdana', 'Trebuchet MS', 'system-ui'] as const;
const SOURCES: readonly LeadSource[] = ['email_gate', 'quote_request', 'pdf_leavebehind'];
const GENERIC_SENT = 'If that address has admin access, a sign-in link is on its way. It expires in 15 minutes.';

type Authed = { session: AdminSession; user: AdminUser };

export function createAdminApi(d: AdminDeps) {
  const log = d.log ?? ((m: string) => console.warn(m));
  /** Background work (sign-in email) — tracked so tests can await it. */
  const pending = new Set<Promise<unknown>>();
  const background = (p: Promise<unknown>) => {
    const t = p.catch((e) => log(`[admin] ${(e as Error).message}`)).finally(() => pending.delete(t));
    pending.add(t);
  };

  const audit = (ctx: TenantContext, actor: string, action: string, target?: string) =>
    d.audit.record({ tenantId: ctx.tenant.id, actor, action, ...(target ? { target } : {}), at: d.now().toISOString() });

  async function authenticate(req: Request, ctx: TenantContext): Promise<Authed | null> {
    const raw = readCookie(req, adminCookieName(ctx.tenant.id));
    if (!isSecretShape(raw)) return null;
    const session = await d.auth.findSession(ctx.tenant.id, hashSecret(raw), d.now());
    if (!session) return null;
    const user = await d.auth.getUser(ctx.tenant.id, session.userId);
    return user ? { session, user } : null; // a removed user loses access immediately
  }

  /** Auth + CSRF + role gate. Returns the caller or an error Response. */
  async function guard(req: Request, ctx: TenantContext, opts: { mutation?: boolean; owner?: boolean } = {}): Promise<Authed | Response> {
    if (opts.mutation && isCrossSite(req)) return fail(403, 'csrf_failed', 'Cross-site request refused.');
    const a = await authenticate(req, ctx);
    if (!a) return fail(401, 'unauthorized', 'Sign in to continue.');
    if (opts.mutation) {
      const token = req.headers.get('x-csrf-token') ?? '';
      if (!safeEqual(token, a.session.csrfToken)) return fail(403, 'csrf_failed', 'Your session token is missing or stale. Reload the page.');
    }
    if (opts.owner && a.user.role !== 'tenant_owner') return fail(403, 'forbidden', 'Only the account owner can change this.');
    return a;
  }

  /* ------------------------------ sign-in ------------------------------ */

  async function signIn(req: Request, ctx: TenantContext): Promise<Response> {
    if (isCrossSite(req)) return fail(403, 'csrf_failed', 'Cross-site request refused.');
    const ip = clientIp(req, d.trustProxy);
    const rl = await limited(d.limits.signIn, `signin:${ctx.tenant.id}:${ip}`);
    if (rl) return rl;
    const b = await readJsonObject(req);
    const email = b ? normalizeEmail(b.email) : null;
    if (!email) return fail(400, 'invalid_body', 'Enter a valid email address.');
    // Per-address cap stops mail-bombing one inbox; the answer stays generic either way.
    if (!(await d.limits.signInEmail.hit(`signin-email:${ctx.tenant.id}:${hashSecret(email)}`)).ok) {
      return jsonResponse(202, { ok: true, message: GENERIC_SENT });
    }
    // Look-up, token and email happen off the response path, so timing doesn't reveal accounts.
    background(
      (async () => {
        const user = await d.auth.findUserByEmail(ctx.tenant.id, email);
        if (!user) return;
        const token = newSecret();
        const now = d.now();
        await d.auth.createLoginToken({
          id: d.newId(),
          tenantId: ctx.tenant.id,
          userId: user.id,
          tokenHash: hashSecret(token),
          expiresAt: new Date(now.getTime() + LOGIN_TOKEN_TTL_MS),
          createdAt: now,
        });
        // Token in the URL FRAGMENT: never sent to servers, logs or Referer; a link scanner
        // fetching the page can't consume it (the page needs a click to POST it).
        const link = `${d.adminUrl(ctx, '/admin/verify')}#token=${token}`;
        await d.email.send({
          to: user.email,
          subject: `Sign in to ${ctx.tenant.branding.displayName}`,
          text: `Use this link to sign in to your ${ctx.tenant.branding.displayName} admin. It works once and expires in 15 minutes.\n\n${link}\n\nIf you didn't ask for this, ignore this email.`,
        });
        await audit(ctx, user.id, 'admin.sign_in_link_sent');
      })(),
    );
    return jsonResponse(202, { ok: true, message: GENERIC_SENT });
  }

  async function verify(req: Request, ctx: TenantContext): Promise<Response> {
    if (isCrossSite(req)) return fail(403, 'csrf_failed', 'Cross-site request refused.');
    const rl = await limited(d.limits.signIn, `verify:${ctx.tenant.id}:${clientIp(req, d.trustProxy)}`);
    if (rl) return rl;
    const b = await readJsonObject(req);
    const bad = () => fail(400, 'invalid_token', 'This sign-in link is invalid, already used or expired. Request a new one.');
    if (!b || !isSecretShape(b.token)) return bad();
    const now = d.now();
    const userId = await d.auth.consumeLoginToken(ctx.tenant.id, hashSecret(b.token), now);
    const user = userId ? await d.auth.getUser(ctx.tenant.id, userId) : null;
    if (!user) return bad();
    const token = newSecret();
    const session: AdminSession = {
      id: d.newId(),
      tenantId: ctx.tenant.id,
      userId: user.id,
      csrfToken: newSecret(),
      expiresAt: new Date(now.getTime() + ADMIN_SESSION_TTL_MS).toISOString(),
    };
    await d.auth.createSession({ ...session, tokenHash: hashSecret(token), createdAt: now });
    await audit(ctx, user.id, 'admin.sign_in');
    return jsonResponse(
      200,
      { ok: true, redirect: d.adminUrl(ctx, '/admin') },
      { 'set-cookie': adminCookieHeader(adminCookieName(ctx.tenant.id), token, ADMIN_SESSION_TTL_MS / 1000, d.secureCookies) },
    );
  }

  async function signOut(req: Request, ctx: TenantContext): Promise<Response> {
    const a = await guard(req, ctx, { mutation: true });
    if (a instanceof Response) return a;
    await d.auth.revokeSession(ctx.tenant.id, a.session.id, d.now());
    await audit(ctx, a.user.id, 'admin.sign_out');
    return jsonResponse(200, { ok: true }, { 'set-cookie': adminCookieHeader(adminCookieName(ctx.tenant.id), '', 0, d.secureCookies) });
  }

  async function me(req: Request, ctx: TenantContext): Promise<Response> {
    const a = await guard(req, ctx);
    if (a instanceof Response) return a;
    return jsonResponse(200, {
      user: { email: a.user.email, role: a.user.role },
      csrfToken: a.session.csrfToken,
      tenant: { name: ctx.tenant.branding.displayName, plan: ctx.tenant.plan },
      // Where leads go right now: the webhook only counts while the tenant is entitled to it.
      routing: leadSettings(ctx).routing.provider === 'webhook' && ctx.can('crm_webhook_routing') ? 'webhook' : 'inbox',
      can: {
        customBranding: ctx.can('custom_branding'),
        webhookRouting: ctx.can('crm_webhook_routing'),
        quoteRequests: ctx.can('quote_requests'),
        leaveBehind: ctx.can('all_lead_paths'),
        pricing: ctx.can('admin_pricing_config'),
      },
    });
  }

  /* ------------------------------- leads ------------------------------- */

  const leadDto = (l: LeadRecord, deliveries: DeliveryBrief[] = []) => ({
    id: l.id,
    email: l.email,
    name: l.name ?? null,
    company: l.company ?? null,
    phone: l.phone ?? null,
    marketingOptIn: l.marketingOptIn,
    consent: l.consent ?? null,
    sources: l.sources,
    createdAt: l.createdAt,
    updatedAt: l.updatedAt,
    delivery: summarise(deliveries),
  });

  /**
   * Worst-first: an admin should see a problem even if a later delivery worked. A delivery to
   * the built-in inbox is `inbox`, not `crm`: only a real CRM delivery earns "Sent to CRM".
   */
  function summarise(ds: DeliveryBrief[]): 'none' | 'inbox' | 'crm' | 'pending' | 'failed' | 'dead' {
    for (const s of ['dead', 'failed', 'pending'] as const) if (ds.some((d) => d.status === s)) return s;
    if (ds.some((d) => d.status === 'delivered' && d.routedTo && d.routedTo !== 'mock')) return 'crm';
    return ds.some((d) => d.status === 'delivered') ? 'inbox' : 'none';
  }

  function parseListQuery(url: URL) {
    const search = (url.searchParams.get('search') ?? '').trim().slice(0, 120);
    const source = url.searchParams.get('source') ?? '';
    const cursor = url.searchParams.get('cursor') ?? '';
    const limit = Math.min(100, Math.max(1, Number(url.searchParams.get('limit') ?? 25) || 25));
    if (source && !SOURCES.includes(source as LeadSource)) return null;
    if (cursor && !/^[A-Za-z0-9_-]{1,200}$/.test(cursor)) return null;
    return { search, source: source as LeadSource | '', cursor, limit, attention: url.searchParams.get('attention') === '1' };
  }

  async function listLeads(req: Request, ctx: TenantContext): Promise<Response> {
    const a = await guard(req, ctx);
    if (a instanceof Response) return a;
    const q = parseListQuery(new URL(req.url));
    if (!q) return fail(400, 'invalid_query', 'Unrecognised filter.');
    const ids = q.attention ? await d.deliveries.leadIdsWithStatus(ctx.tenant.id, ['failed', 'dead'], 1000) : undefined;
    const page = await d.leads.list(ctx.tenant.id, {
      limit: q.limit,
      ...(q.cursor ? { cursor: q.cursor } : {}),
      ...(q.search ? { search: q.search } : {}),
      ...(q.source ? { source: q.source } : {}),
      ...(ids ? { ids } : {}),
    });
    const st = await d.deliveries.statusesFor(ctx.tenant.id, page.items.map((l) => l.id));
    return jsonResponse(200, { items: page.items.map((l) => leadDto(l, st[l.id])), nextCursor: page.nextCursor });
  }

  async function leadDetail(req: Request, ctx: TenantContext, id: string): Promise<Response> {
    const a = await guard(req, ctx);
    if (a instanceof Response) return a;
    if (!UUID.test(id)) return fail(404, 'not_found', 'Lead not found.');
    const lead = await d.leads.get(ctx.tenant.id, id);
    if (!lead) return fail(404, 'not_found', 'Lead not found.');
    const [events, deliveries] = await Promise.all([d.leads.events(ctx.tenant.id, id), d.deliveries.forLead(ctx.tenant.id, id)]);
    return jsonResponse(200, {
      lead: leadDto(lead, deliveries),
      events: events.sort((x, y) => x.createdAt.localeCompare(y.createdAt)).map((e) => ({ kind: e.kind, at: e.createdAt, payload: e.payload })),
      deliveries: deliveries.map((x) => ({
        id: x.id,
        source: x.source,
        status: x.status,
        attempts: x.attempts,
        nextAttemptAt: x.nextAttemptAt,
        lastError: x.lastError ?? null,
        routedTo: x.routedTo ?? null,
        toCrm: x.status === 'delivered' && !!x.routedTo && x.routedTo !== 'mock',
        createdAt: x.createdAt,
        retryable: x.status === 'failed' || x.status === 'dead',
      })),
    });
  }

  /** Spreadsheet-safe CSV: quoted, and formula-leading cells defused (CSV injection). */
  const cell = (v: unknown) => {
    let s = v === null || v === undefined ? '' : String(v);
    if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`;
    return `"${s.replace(/"/g, '""')}"`;
  };

  async function exportCsv(req: Request, ctx: TenantContext): Promise<Response> {
    const a = await guard(req, ctx);
    if (a instanceof Response) return a;
    const header = ['email', 'name', 'company', 'phone', 'marketing_opt_in', 'consent_version', 'consent_at', 'sources', 'created_at', 'crm_delivery'];
    const lines = [header.join(',')];
    let cursor: string | undefined;
    for (let pages = 0; pages < 100; pages++) {
      const page = await d.leads.list(ctx.tenant.id, { limit: 100, ...(cursor ? { cursor } : {}) });
      const st = await d.deliveries.statusesFor(ctx.tenant.id, page.items.map((l) => l.id));
      for (const l of page.items) {
        lines.push(
          [l.email, l.name, l.company, l.phone, l.marketingOptIn ? 'yes' : 'no', l.consent?.version, l.consent?.at, l.sources.join(' '), l.createdAt, summarise(st[l.id] ?? [])]
            .map(cell)
            .join(','),
        );
      }
      if (!page.nextCursor) break;
      cursor = page.nextCursor;
    }
    await audit(ctx, a.user.id, 'leads.export_csv', `${lines.length - 1} rows`);
    const day = d.now().toISOString().slice(0, 10);
    return new Response('\ufeff' + lines.join('\r\n') + '\r\n', {
      status: 200,
      headers: {
        'content-type': 'text/csv; charset=utf-8',
        'content-disposition': `attachment; filename="leads-${ctx.tenant.slug}-${day}.csv"`,
        'cache-control': 'no-store',
      },
    });
  }

  async function retryDelivery(req: Request, ctx: TenantContext, id: string): Promise<Response> {
    const a = await guard(req, ctx, { mutation: true });
    if (a instanceof Response) return a;
    if (!UUID.test(id)) return fail(404, 'not_found', 'Delivery not found.');
    const r = await d.delivery.retryNow(ctx, id);
    if (!r) return fail(404, 'not_found', 'Nothing to retry: the delivery is unknown or already delivered.');
    await audit(ctx, a.user.id, 'delivery.retry', id);
    return jsonResponse(200, { status: r.status, attempts: r.attempts, lastError: r.lastError ?? null });
  }

  /* ------------------------------ settings ----------------------------- */

  const leadSettings = (ctx: TenantContext): LeadSettings => ctx.tenant.leads ?? DEFAULT_LEAD_SETTINGS;

  async function getSettings(req: Request, ctx: TenantContext): Promise<Response> {
    const a = await guard(req, ctx);
    if (a instanceof Response) return a;
    const ls = leadSettings(ctx);
    const b = ctx.tenant.branding;
    return jsonResponse(200, {
      branding: { displayName: b.displayName, primaryHex: b.primaryHex, secondaryHex: b.secondaryHex, fontFamily: b.fontFamily },
      fonts: FONTS,
      gate: { ...ls.gate, contactName: ls.contactName ?? '' },
      routing: ls.routing.provider === 'webhook' ? { provider: 'webhook', url: ls.routing.url, hasSecret: true } : { provider: 'mock' },
      can: { customBranding: ctx.can('custom_branding'), webhookRouting: ctx.can('crm_webhook_routing'), pricing: ctx.can('admin_pricing_config') },
      isOwner: a.user.role === 'tenant_owner',
      recentActivity: await recentActivity(ctx),
    });
  }

  /** Last changes with WHO made them (email, or "the system"); details stay in the audit log. */
  async function recentActivity(ctx: TenantContext) {
    const rows = await d.audit.recent(ctx.tenant.id, 10);
    const names = new Map<string, string>();
    for (const id of new Set(rows.map((r) => r.actor))) {
      names.set(id, id === 'system' ? 'the system' : ((await d.auth.getUser(ctx.tenant.id, id))?.email ?? 'a removed user'));
    }
    return rows.map((e) => ({ action: e.action, at: e.at, target: e.target ?? null, by: names.get(e.actor)! }));
  }

  const text = (v: unknown, max: number) => (typeof v === 'string' && v.trim().length > 0 && v.trim().length <= max ? v.trim().replace(/\s+/g, ' ') : null);

  async function putBranding(req: Request, ctx: TenantContext): Promise<Response> {
    const a = await guard(req, ctx, { mutation: true });
    if (a instanceof Response) return a;
    const gate = locked(ctx, 'custom_branding');
    if (gate) return gate;
    const b = await readJsonObject(req);
    if (!b) return fail(400, 'invalid_body', 'Send a JSON object.');
    const errors: Record<string, string> = {};
    const displayName = text(b.displayName, 80);
    if (!displayName) errors.displayName = 'Enter a name up to 80 characters.';
    if (typeof b.primaryHex !== 'string' || !HEX.test(b.primaryHex)) errors.primaryHex = 'Use a hex colour like #1F45C6.';
    if (typeof b.secondaryHex !== 'string' || !HEX.test(b.secondaryHex)) errors.secondaryHex = 'Use a hex colour like #111827.';
    if (!FONTS.includes(b.fontFamily as (typeof FONTS)[number])) errors.fontFamily = 'Choose one of the listed fonts.';
    if (Object.keys(errors).length) return fail(422, 'invalid_body', 'Check the highlighted fields.', { errors });
    await d.settings.updateBranding(ctx.tenant.id, {
      displayName: displayName!,
      primaryHex: (b.primaryHex as string).toUpperCase(),
      secondaryHex: (b.secondaryHex as string).toUpperCase(),
      fontFamily: b.fontFamily as string,
    });
    await audit(ctx, a.user.id, 'settings.branding');
    return jsonResponse(200, { ok: true });
  }

  async function putGate(req: Request, ctx: TenantContext): Promise<Response> {
    const a = await guard(req, ctx, { mutation: true });
    if (a instanceof Response) return a;
    const b = await readJsonObject(req);
    if (!b) return fail(400, 'invalid_body', 'Send a JSON object.');
    const errors: Record<string, string> = {};
    const mode = b.mode as GateMode;
    if (!['off', 'soft', 'hard'].includes(mode)) errors.mode = 'Choose off, soft or hard.';
    const free = Number(b.freeProducts);
    if (!Number.isInteger(free) || free < 0 || free > 20) errors.freeProducts = 'Enter a whole number from 0 to 20.';
    const contact = b.contactName === '' || b.contactName === undefined ? '' : text(b.contactName, 80);
    if (contact === null) errors.contactName = 'Up to 80 characters.';
    if (Object.keys(errors).length) return fail(422, 'invalid_body', 'Check the highlighted fields.', { errors });
    const cur = leadSettings(ctx);
    const next: LeadSettings = { gate: { mode, freeProducts: free }, routing: cur.routing, ...(contact ? { contactName: contact } : {}) };
    await d.settings.updateLeadSettings(ctx.tenant.id, next);
    await audit(ctx, a.user.id, 'settings.gate', `${mode}/${free}`);
    return jsonResponse(200, { ok: true });
  }

  async function putRouting(req: Request, ctx: TenantContext): Promise<Response> {
    const a = await guard(req, ctx, { mutation: true, owner: true });
    if (a instanceof Response) return a;
    const b = await readJsonObject(req);
    if (!b) return fail(400, 'invalid_body', 'Send a JSON object.');
    const cur = leadSettings(ctx);
    if (b.provider === 'mock') {
      await d.settings.updateLeadSettings(ctx.tenant.id, { ...cur, routing: { provider: 'mock' } });
      await audit(ctx, a.user.id, 'settings.routing', 'inbox');
      return jsonResponse(200, { ok: true });
    }
    if (b.provider !== 'webhook') return fail(422, 'invalid_body', 'Choose inbox or webhook.');
    const gate = locked(ctx, 'crm_webhook_routing');
    if (gate) return gate;
    const url = typeof b.url === 'string' ? b.url.trim() : '';
    const problem = url.length > 2000 ? 'is too long' : webhookUrlProblem(url, d.webhook?.allowInsecure ?? false);
    if (problem) return fail(422, 'invalid_body', `That URL ${problem}.`, { errors: { url: `URL ${problem}.` } });
    // Keep the existing secret unless asked to rotate; a new secret is shown exactly once.
    let secret: string | null = null;
    let sealed = cur.routing.provider === 'webhook' ? cur.routing.secretSealed : null;
    if (!sealed || b.rotateSecret === true) {
      secret = `whsec_${newSecret()}`;
      sealed = d.secrets.seal(secret, ctx.tenant.id);
    }
    await d.settings.updateLeadSettings(ctx.tenant.id, { ...cur, routing: { provider: 'webhook', url, secretSealed: sealed } });
    await audit(ctx, a.user.id, 'settings.routing', `webhook ${new URL(url).host}${secret ? ' (new secret)' : ''}`);
    return jsonResponse(200, { ok: true, ...(secret ? { secret } : {}) });
  }

  async function testRouting(req: Request, ctx: TenantContext): Promise<Response> {
    const a = await guard(req, ctx, { mutation: true, owner: true });
    if (a instanceof Response) return a;
    const gate = locked(ctx, 'crm_webhook_routing');
    if (gate) return gate;
    const r = leadSettings(ctx).routing;
    if (r.provider !== 'webhook') return fail(409, 'invalid_request', 'Save a webhook URL first.');
    const rl = await limited(d.limits.signIn, `webhook-test:${ctx.tenant.id}`);
    if (rl) return rl;
    try {
      const p = new WebhookCrmProvider(r.url, d.secrets.open(r.secretSealed, ctx.tenant.id), d.webhook ?? {});
      await p.ping(ctx.tenant.id);
      await audit(ctx, a.user.id, 'settings.routing_test', 'ok');
      return jsonResponse(200, { ok: true });
    } catch (e) {
      const error = (e as Error).message.slice(0, 200);
      await audit(ctx, a.user.id, 'settings.routing_test', 'failed');
      return jsonResponse(200, { ok: false, error });
    }
  }

  /* ------------------------------- pricing ------------------------------ */

  const categoriesOf = async (ctx: TenantContext) => [...new Set((await d.products.list(ctx.tenant.id)).map((p) => p.category))].sort();

  /** The config as the editor shows it: rates always filled in (placeholder where unset). */
  const editable = (c: TenantPricingConfig): TenantPricingConfig => ({ ...c, rates: resolveRates(c.rates) });

  async function getPricing(req: Request, ctx: TenantContext): Promise<Response> {
    const a = await guard(req, ctx);
    if (a instanceof Response) return a;
    const gate = locked(ctx, 'admin_pricing_config');
    if (gate) return gate;
    return jsonResponse(200, {
      config: editable(ctx.tenant.pricingConfig),
      usingOwnRates: !!ctx.tenant.pricingConfig.rates,
      defaults: { ...PLACEHOLDER_TENANT_CONFIG, rates: PLACEHOLDER_RATES },
      categories: await categoriesOf(ctx),
      methods: ctx.methods.map((m) => ({ key: m, label: DECORATION_METHODS[m].label })),
      isOwner: a.user.role === 'tenant_owner',
    });
  }

  async function validateFor(ctx: TenantContext, raw: unknown) {
    return validatePricingConfig(raw, { categories: await categoriesOf(ctx), currency: ctx.tenant.pricingConfig.currency });
  }

  /** One line for the audit log: what changed, in the admin's terms. */
  function pricingDiff(a: TenantPricingConfig, b: TenantPricingConfig): string {
    const pct = (x: number) => `${Math.round((x - 1) * 10_000) / 100}%`;
    const out: string[] = [];
    if (a.marginMarkup !== b.marginMarkup) out.push(`blank markup ${pct(a.marginMarkup)} → ${pct(b.marginMarkup)}`);
    if (a.decorationMarkup !== b.decorationMarkup) out.push(`decoration markup ${pct(a.decorationMarkup)} → ${pct(b.decorationMarkup)}`);
    if (JSON.stringify(a.categoryMarkupOverrides ?? {}) !== JSON.stringify(b.categoryMarkupOverrides ?? {})) out.push('category markups');
    if (JSON.stringify(a.fees) !== JSON.stringify(b.fees)) out.push('fees');
    if (a.rounding !== b.rounding) out.push(`rounding ${a.rounding} → ${b.rounding}`);
    if (a.showItemizedToProspect !== b.showItemizedToProspect) out.push(b.showItemizedToProspect ? 'breakdown shown' : 'breakdown hidden');
    const ra = resolveRates(a.rates);
    const rb = resolveRates(b.rates);
    const changed = (Object.keys(rb) as (keyof typeof rb)[]).filter((k) => JSON.stringify(ra[k]) !== JSON.stringify(rb[k]));
    if (changed.length) out.push(`rates: ${changed.map((k) => DECORATION_METHODS[k].label).join(', ')}`);
    return out.join('; ').slice(0, 300) || 'no change';
  }

  async function putPricing(req: Request, ctx: TenantContext): Promise<Response> {
    const a = await guard(req, ctx, { mutation: true, owner: true });
    if (a instanceof Response) return a;
    const gate = locked(ctx, 'admin_pricing_config');
    if (gate) return gate;
    const b = await readJsonObject(req, 64 * 1024);
    if (!b) return fail(400, 'invalid_body', 'Send a JSON object.');
    const v = await validateFor(ctx, b.config);
    if (!v.ok) return fail(422, 'invalid_body', 'Check the highlighted fields.', { errors: v.errors });
    await d.settings.updatePricingConfig(ctx.tenant.id, v.value);
    await audit(ctx, a.user.id, 'settings.pricing', pricingDiff(ctx.tenant.pricingConfig, v.value));
    return jsonResponse(200, { ok: true, warnings: v.warnings });
  }

  /**
   * Price every product at a sample order with an UNSAVED config, beside today's prices.
   * Read-only: any admin may use it; nothing is stored.
   */
  async function previewPricing(req: Request, ctx: TenantContext): Promise<Response> {
    if (isCrossSite(req)) return fail(403, 'csrf_failed', 'Cross-site request refused.');
    const a = await guard(req, ctx);
    if (a instanceof Response) return a;
    const gate = locked(ctx, 'admin_pricing_config');
    if (gate) return gate;
    const b = await readJsonObject(req, 64 * 1024);
    if (!b) return fail(400, 'invalid_body', 'Send a JSON object.');
    const quantity = Number(b.quantity);
    const colorCount = Number(b.colorCount);
    if (!Number.isInteger(quantity) || quantity < 1 || quantity > 100_000) return fail(422, 'invalid_body', 'Quantity must be 1 to 100,000.', { errors: { quantity: 'Enter 1 to 100,000.' } });
    if (!Number.isInteger(colorCount) || colorCount < 1 || colorCount > 12) return fail(422, 'invalid_body', 'Colours must be 1 to 12.', { errors: { colorCount: 'Enter 1 to 12.' } });
    const v = await validateFor(ctx, b.config);
    if (!v.ok) return fail(422, 'invalid_body', 'Check the highlighted fields.', { errors: v.errors });
    const products = await d.products.list(ctx.tenant.id);
    const q = { quantity, logo: { colorCount, isPhotographic: false }, entitledMethods: ctx.methods };
    const now = new Map(searchCatalog(products, q, ctx.tenant.pricingConfig).items.map((i) => [i.slug, i.recommended]));
    const next = searchCatalog(products, q, v.value).items;
    return jsonResponse(200, {
      quantity,
      colorCount,
      warnings: v.warnings,
      disclaimer: disclaimerFor(v.value),
      rows: next.map((i) => ({
        slug: i.slug,
        name: i.name,
        category: i.category,
        method: DECORATION_METHODS[i.recommended.method].label,
        unit: i.recommended.unit,
        total: i.recommended.total,
        currentUnit: now.get(i.slug)?.unit ?? null,
        lines: v.value.showItemizedToProspect ? prospectLines(i.recommended.quote) : null,
      })),
    });
  }

  return {
    getPricing,
    putPricing,
    previewPricing,
    signIn,
    verify,
    signOut,
    me,
    listLeads,
    leadDetail,
    exportCsv,
    retryDelivery,
    getSettings,
    putBranding,
    putGate,
    putRouting,
    testRouting,
    authenticate,
    /** Tests: wait for background sign-in work. */
    settled: () => Promise.all([...pending]),
  };
}

export type AdminApi = ReturnType<typeof createAdminApi>;
