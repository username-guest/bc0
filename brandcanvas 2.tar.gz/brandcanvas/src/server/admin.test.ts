/** Tenant admin (ADR 0008): magic-link sign-in, sessions, CSRF, roles, settings, inbox, export. */
import { describe, it, expect } from 'vitest';
import { createServer } from 'node:http';
import { createHmac } from 'node:crypto';
import type { AddressInfo } from 'node:net';
import { buildFixture, FREE_TENANT_ID } from './testing';
import { handleTenantApi } from './http/router';
import { DEMO_TENANT_ID } from '@/core/domain/demo-catalog';
import { MockEmailProvider } from '@/shared/providers/mocks';
import { BACKOFF_MS } from './leads/delivery';

type Fx = ReturnType<typeof buildFixture>;

function setup(opts: Parameters<typeof buildFixture>[0] = {}) {
  let now = new Date('2026-09-01T12:00:00Z');
  const email = new MockEmailProvider();
  const fx = buildFixture({ email, now: () => now, ...opts });
  const advance = (ms: number) => (now = new Date(now.getTime() + ms));
  return { fx, email, advance, clock: () => now };
}

/** A browser-ish client for one tenant: cookie jar + CSRF header once signed in. */
function browser(fx: Fx, ref: string) {
  const jar = new Map<string, string>();
  const cookieHeader = () => [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
  let csrf = '';
  async function call(sub: string, init: RequestInit & { headers?: Record<string, string> } = {}) {
    const headers: Record<string, string> = { ...(init.headers ?? {}) };
    if (jar.size) headers.cookie = cookieHeader();
    if (csrf && init.method && init.method !== 'GET') headers['x-csrf-token'] ??= csrf;
    const req = new Request(`http://localhost/api/t/${ref}/${sub}`, { ...init, headers });
    const res = await handleTenantApi(req, ref, sub.split('?')[0]!.split('/'), { api: fx.api, admin: fx.admin, directory: fx.directory });
    const set = res.headers.get('set-cookie');
    if (set) {
      const [pair] = set.split(';');
      const i = pair!.indexOf('=');
      const [k, v] = [pair!.slice(0, i), pair!.slice(i + 1)];
      if (v) jar.set(k, v);
      else jar.delete(k);
    }
    return res;
  }
  const send = (method: string, sub: string, body: unknown, headers: Record<string, string> = {}) =>
    call(sub, { method, headers: { 'content-type': 'application/json', ...headers }, body: JSON.stringify(body) });
  return {
    call,
    send,
    /** The whole jar as a Cookie header; assigning replaces the jar. */
    get cookie() {
      return cookieHeader();
    },
    set cookie(v: string) {
      jar.clear();
      for (const part of v.split('; ').filter(Boolean)) {
        const i = part.indexOf('=');
        jar.set(part.slice(0, i), part.slice(i + 1));
      }
    },
    async signIn(mail: MockEmailProvider, address: string) {
      await send('POST', 'admin/sign-in', { email: address });
      await fx.admin.settled();
      const token = tokenFrom(mail.sent[mail.sent.length - 1]!.text);
      const r = await send('POST', 'admin/verify', { token });
      expect(r.status).toBe(200);
      csrf = (await (await call('admin/me')).json()).csrfToken;
      return r;
    },
    dropCsrf() {
      csrf = '';
    },
  };
}
const tokenFrom = (text: string) => /#token=([A-Za-z0-9_-]{43})/.exec(text)![1]!;

describe('magic-link sign-in', () => {
  it('answers the same way for unknown addresses and sends nothing', async () => {
    const { fx, email } = setup();
    const b = browser(fx, 'demo');
    const known = await b.send('POST', 'admin/sign-in', { email: 'OWNER@demo.test ' });
    const unknown = await b.send('POST', 'admin/sign-in', { email: 'nobody@demo.test' });
    await fx.admin.settled();
    expect(known.status).toBe(202);
    expect(unknown.status).toBe(202);
    expect(await known.json()).toEqual(await unknown.json());
    expect(email.sent.map((m) => m.to)).toEqual(['owner@demo.test']);
  });

  it("builds the link from config, never from the request's Host header", async () => {
    const { fx, email } = setup({ publicBaseUrl: 'https://app.brandcanvas.test' });
    await handleTenantApi(
      new Request('http://evil.example/api/t/demo/admin/sign-in', {
        method: 'POST',
        headers: { host: 'evil.example', 'x-forwarded-host': 'evil.example', 'content-type': 'application/json' },
        body: JSON.stringify({ email: 'owner@demo.test' }),
      }),
      'demo',
      ['admin', 'sign-in'],
      { api: fx.api, admin: fx.admin, directory: fx.directory },
    );
    await fx.admin.settled();
    const text = email.sent[0]!.text;
    expect(text).toContain('https://app.brandcanvas.test/t/demo/admin/verify#token=');
    expect(text).not.toContain('evil.example');
  });

  it('a link works once, expires after 15 minutes and only for its own tenant', async () => {
    const { fx, email, advance } = setup();
    const b = browser(fx, 'demo');
    await b.send('POST', 'admin/sign-in', { email: 'owner@demo.test' });
    await fx.admin.settled();
    const token = tokenFrom(email.sent[0]!.text);

    expect((await browser(fx, 'basic').send('POST', 'admin/verify', { token })).status).toBe(400); // other tenant
    const ok = await b.send('POST', 'admin/verify', { token });
    expect(ok.status).toBe(200);
    expect(ok.headers.get('set-cookie')).toMatch(/HttpOnly; SameSite=Lax/);
    expect((await b.send('POST', 'admin/verify', { token })).status).toBe(400); // reused

    await b.send('POST', 'admin/sign-in', { email: 'owner@demo.test' });
    await fx.admin.settled();
    advance(15 * 60_000 + 1);
    expect((await b.send('POST', 'admin/verify', { token: tokenFrom(email.sent[1]!.text) })).status).toBe(400); // expired
    expect((await b.send('POST', 'admin/verify', { token: 'short' })).status).toBe(400);
  });

  it('refuses cross-site sign-in and verify (login CSRF)', async () => {
    const { fx } = setup();
    const b = browser(fx, 'demo');
    const r = await b.send('POST', 'admin/sign-in', { email: 'owner@demo.test' }, { 'sec-fetch-site': 'cross-site' });
    expect(r.status).toBe(403);
  });

  it('caps links per address without changing the answer', async () => {
    const { fx, email } = setup();
    const b = browser(fx, 'demo');
    for (let i = 0; i < 7; i++) expect((await b.send('POST', 'admin/sign-in', { email: 'owner@demo.test' })).status).toBe(202);
    await fx.admin.settled();
    expect(email.sent).toHaveLength(5);
  });
});

describe('admin sessions', () => {
  it('needs a session; a session is scoped to its tenant; sign-out and expiry end it', async () => {
    const { fx, email, advance } = setup();
    const b = browser(fx, 'demo');
    expect((await b.call('admin/me')).status).toBe(401);
    await b.signIn(email, 'owner@demo.test');
    const me = await (await b.call('admin/me')).json();
    expect(me.user).toEqual({ email: 'owner@demo.test', role: 'tenant_owner' });

    const other = browser(fx, 'basic');
    other.cookie = b.cookie; // replay demo's cookie against another tenant
    expect((await other.call('admin/me')).status).toBe(401);

    const saved = b.cookie;
    expect((await b.send('POST', 'admin/sign-out', {})).status).toBe(200);
    b.cookie = saved; // an old copy of the cookie is dead server-side
    expect((await b.call('admin/me')).status).toBe(401);

    const c = browser(fx, 'demo');
    await c.signIn(email, 'owner@demo.test');
    advance(12 * 3_600_000 + 1);
    expect((await c.call('admin/me')).status).toBe(401);
  });

  it('mutations need the CSRF token', async () => {
    const { fx, email } = setup();
    const b = browser(fx, 'demo');
    await b.signIn(email, 'owner@demo.test');
    const body = { mode: 'soft', freeProducts: 2 };
    expect((await b.send('PUT', 'admin/settings/gate', body, { 'x-csrf-token': 'wrong' })).status).toBe(403);
    expect((await b.send('PUT', 'admin/settings/gate', body, { 'sec-fetch-site': 'cross-site' })).status).toBe(403);
    expect((await b.send('PUT', 'admin/settings/gate', body)).status).toBe(200);
    b.dropCsrf();
    expect((await b.send('PUT', 'admin/settings/gate', body)).status).toBe(403);
  });
});

describe('settings', () => {
  it('gate changes apply to the storefront immediately', async () => {
    const { fx, email } = setup();
    const b = browser(fx, 'demo');
    await b.signIn(email, 'staff@demo.test'); // non-owner admins can change the gate
    expect((await b.send('PUT', 'admin/settings/gate', { mode: 'soft', freeProducts: 1, contactName: 'Sam' })).status).toBe(200);
    const cfg = await (await b.call('config')).json();
    expect(JSON.stringify(cfg)).toContain('"mode":"soft"');
    const bad = await b.send('PUT', 'admin/settings/gate', { mode: 'wide-open', freeProducts: 99 });
    expect(bad.status).toBe(422);
    expect(Object.keys((await bad.json()).error.errors).sort()).toEqual(['freeProducts', 'mode']);
  });

  it('branding needs the Starter entitlement and validates input', async () => {
    const { fx, email } = setup();
    const free = browser(fx, 'basic');
    await free.signIn(email, 'owner@basic.test');
    const body = { displayName: 'New Name', primaryHex: '#112233', secondaryHex: '#445566', fontFamily: 'Georgia' };
    expect((await free.send('PUT', 'admin/settings/branding', body)).status).toBe(403);

    const pro = browser(fx, 'demo');
    await pro.signIn(email, 'owner@demo.test');
    expect((await pro.send('PUT', 'admin/settings/branding', { ...body, primaryHex: 'red', fontFamily: 'Comic Sans' })).status).toBe(422);
    expect((await pro.send('PUT', 'admin/settings/branding', body)).status).toBe(200);
    expect((await fx.directory.findBySlug('demo'))!.branding.displayName).toBe('New Name');
  });

  it('webhook secret: generated once, stored sealed, never returned again; owner only', async () => {
    const { fx, email } = setup();
    const staff = browser(fx, 'demo');
    await staff.signIn(email, 'staff@demo.test');
    expect((await staff.send('PUT', 'admin/settings/routing', { provider: 'webhook', url: 'https://hooks.example.com/a' })).status).toBe(403);

    const owner = browser(fx, 'demo');
    await owner.signIn(email, 'owner@demo.test');
    expect((await owner.send('PUT', 'admin/settings/routing', { provider: 'webhook', url: 'https://127.0.0.1/x' })).status).toBe(422);
    const first = await (await owner.send('PUT', 'admin/settings/routing', { provider: 'webhook', url: 'https://hooks.example.com/a' })).json();
    expect(first.secret).toMatch(/^whsec_/);

    const stored = (await fx.directory.findBySlug('demo'))!.leads!.routing;
    expect(JSON.stringify(stored)).not.toContain(first.secret);
    expect(fx.secrets.open((stored as { secretSealed: string }).secretSealed, DEMO_TENANT_ID)).toBe(first.secret);

    const settings = JSON.stringify(await (await owner.call('admin/settings')).json());
    expect(settings).not.toContain(first.secret);
    expect(settings).not.toContain('secretSealed');

    const again = await (await owner.send('PUT', 'admin/settings/routing', { provider: 'webhook', url: 'https://hooks.example.com/b' })).json();
    expect(again.secret).toBeUndefined(); // kept
    const rotated = await (await owner.send('PUT', 'admin/settings/routing', { provider: 'webhook', url: 'https://hooks.example.com/b', rotateSecret: true })).json();
    expect(rotated.secret).toMatch(/^whsec_/);
    expect(rotated.secret).not.toBe(first.secret);
  });

  it('Free plan cannot enable webhook routing', async () => {
    const { fx, email } = setup();
    const b = browser(fx, 'basic');
    await b.signIn(email, 'owner@basic.test');
    expect((await b.send('PUT', 'admin/settings/routing', { provider: 'webhook', url: 'https://hooks.example.com/a' })).status).toBe(403);
  });

  it('"send test" delivers a signed ping', async () => {
    const got: { body: string; sig: string }[] = [];
    const srv = createServer((req, res) => {
      let body = '';
      req.on('data', (c) => (body += c));
      req.on('end', () => {
        got.push({ body, sig: String(req.headers['x-brandcanvas-signature']) });
        res.end('ok');
      });
    });
    await new Promise<void>((r) => srv.listen(0, '127.0.0.1', r));
    try {
      const { fx, email } = setup({ allowInsecureWebhooks: true });
      const b = browser(fx, 'demo');
      await b.signIn(email, 'owner@demo.test');
      const url = `http://127.0.0.1:${(srv.address() as AddressInfo).port}/hook`;
      const { secret } = await (await b.send('PUT', 'admin/settings/routing', { provider: 'webhook', url })).json();
      expect(await (await b.send('POST', 'admin/settings/routing/test', {})).json()).toEqual({ ok: true });
      expect(JSON.parse(got[0]!.body).type).toBe('ping');
      const [t, v1] = got[0]!.sig.split(',').map((x) => x.split('=')[1]);
      expect(v1).toBe(createHmac('sha256', secret).update(`${t}.${got[0]!.body}`).digest('hex'));
    } finally {
      await new Promise<void>((r) => srv.close(() => r()));
    }
  });
});

describe('lead inbox', () => {
  async function seed(fx: Fx, clock: () => Date, advance: (ms: number) => void) {
    const mk = async (email: string, name: string, source: 'email_gate' | 'quote_request') => {
      await fx.leads.upsertByEmail(DEMO_TENANT_ID, { email, name, source, marketingOptIn: false, consentVersion: 'v1' }, clock());
      advance(1000);
    };
    await mk('a@acme.test', 'Ann Acme', 'email_gate');
    await mk('b@bolt.test', '=HYPERLINK("http://x","click")', 'quote_request');
    await mk('c@acme.test', 'Cy', 'email_gate');
    await fx.leads.upsertByEmail(FREE_TENANT_ID, { email: 'other@tenant.test', source: 'email_gate', marketingOptIn: false, consentVersion: 'v1' }, clock());
  }

  it('pages newest-first, filters, and never shows another tenant', async () => {
    const { fx, email, clock, advance } = setup();
    await seed(fx, clock, advance);
    const b = browser(fx, 'demo');
    await b.signIn(email, 'staff@demo.test');
    const p1 = await (await b.call('admin/leads?limit=2')).json();
    expect(p1.items.map((l: { email: string }) => l.email)).toEqual(['c@acme.test', 'b@bolt.test']);
    const p2 = await (await b.call(`admin/leads?limit=2&cursor=${p1.nextCursor}`)).json();
    expect(p2.items.map((l: { email: string }) => l.email)).toEqual(['a@acme.test']);
    expect(p2.nextCursor).toBeNull();
    const s = await (await b.call('admin/leads?search=ACME')).json();
    expect(s.items).toHaveLength(2);
    const q = await (await b.call('admin/leads?source=quote_request')).json();
    expect(q.items.map((l: { email: string }) => l.email)).toEqual(['b@bolt.test']);
    expect((await b.call('admin/leads?source=nope')).status).toBe(400);

    const foreign = (await fx.leads.list(FREE_TENANT_ID, { limit: 1 })).items[0]!;
    expect((await b.call(`admin/leads/${foreign.id}`)).status).toBe(404);
  });

  it('shows failed deliveries, filters to them, and retries on request', async () => {
    const { fx, email, clock } = setup({ allowInsecureWebhooks: true });
    const b = browser(fx, 'demo');
    await b.signIn(email, 'owner@demo.test');
    await b.send('PUT', 'admin/settings/routing', { provider: 'webhook', url: 'http://127.0.0.1:9/down' });
    const capture = await b.send('POST', 'leads/email', { email: 'lost@acme.test', startedAt: clock().getTime() - 5000, website: '' });
    expect(capture.status).toBe(201);

    const inbox = await (await b.call('admin/leads?attention=1')).json();
    expect(inbox.items).toHaveLength(1);
    expect(inbox.items[0].delivery).toBe('failed');
    const detail = await (await b.call(`admin/leads/${inbox.items[0].id}`)).json();
    expect(detail.events.map((e: { kind: string }) => e.kind)).toEqual(['captured', 'routing_failed']);
    const d = detail.deliveries[0];
    expect(d).toMatchObject({ status: 'failed', attempts: 1, retryable: true });

    await b.send('PUT', 'admin/settings/routing', { provider: 'mock' }); // fix routing, then retry by hand
    const r = await (await b.send('POST', `admin/deliveries/${d.id}/retry`, {})).json();
    expect(r).toMatchObject({ status: 'delivered', attempts: 2 });
    // Delivered to the built-in inbox, NOT to a CRM: the inbox must not claim "Sent to CRM".
    const after = await (await b.call('admin/leads')).json();
    expect(after.items[0].delivery).toBe('inbox');
    expect((await b.send('POST', `admin/deliveries/${d.id}/retry`, {})).status).toBe(404);
    expect(BACKOFF_MS.length).toBeGreaterThan(0);
  });

  it('CSV export defuses spreadsheet formulas and is audited', async () => {
    const { fx, email, clock, advance } = setup();
    await seed(fx, clock, advance);
    const b = browser(fx, 'demo');
    await b.signIn(email, 'staff@demo.test');
    const res = await b.call('admin/leads.csv');
    expect(res.headers.get('content-type')).toMatch(/text\/csv/);
    expect(res.headers.get('content-disposition')).toMatch(/attachment; filename="leads-demo-/);
    const csv = await res.text();
    const rows = csv.trim().split('\r\n');
    expect(rows).toHaveLength(4); // header + 3 demo leads, none from other tenants
    expect(csv).toContain(`"'=HYPERLINK(""http://x"",""click"")"`);
    expect(csv).not.toContain('other@tenant.test');
    const actions = (await fx.audit.recent(DEMO_TENANT_ID, 10)).map((e) => e.action);
    expect(actions).toContain('leads.export_csv');
    expect(actions).toContain('admin.sign_in');
    expect((await fx.audit.recent(FREE_TENANT_ID, 10)).map((e) => e.action)).not.toContain('leads.export_csv');
  });
});

describe('pricing admin', () => {
  const load = async (b: ReturnType<typeof browser>) => (await (await b.call('admin/settings/pricing')).json()) as { config: Record<string, any>; categories: string[]; methods: { key: string }[] };
  const catalogUnits = async (b: ReturnType<typeof browser>) =>
    Object.fromEntries(((await (await b.call('catalog?qty=144')).json()).items as { slug: string; unit: number }[]).map((i) => [i.slug, i.unit]));

  it('needs the Starter plan', async () => {
    const { fx, email } = setup();
    const b = browser(fx, 'basic');
    await b.signIn(email, 'owner@basic.test');
    expect((await b.call('admin/settings/pricing')).status).toBe(403);
    expect((await b.send('POST', 'admin/settings/pricing/preview', { config: {}, quantity: 144, colorCount: 2 })).status).toBe(403);
    expect((await b.send('PUT', 'admin/settings/pricing', { config: {} })).status).toBe(403);
  });

  it('staff can view and preview but only the owner can save', async () => {
    const { fx, email } = setup();
    const staff = browser(fx, 'demo');
    await staff.signIn(email, 'staff@demo.test');
    const { config } = await load(staff);
    expect(config.rates.screen_print.runByBreak.length).toBeGreaterThan(0); // rates always filled in
    expect((await staff.send('POST', 'admin/settings/pricing/preview', { config, quantity: 144, colorCount: 2 })).status).toBe(200);
    expect((await staff.send('PUT', 'admin/settings/pricing', { config })).status).toBe(403);
  });

  it('preview prices every product with unsaved values, beside current prices, and stores nothing', async () => {
    const { fx, email } = setup();
    const b = browser(fx, 'demo');
    await b.signIn(email, 'owner@demo.test');
    const { config } = await load(b);
    const higher = { ...config, marginMarkup: 2, showItemizedToProspect: false };
    const p = await (await b.send('POST', 'admin/settings/pricing/preview', { config: higher, quantity: 144, colorCount: 2 })).json();
    expect(p.rows.length).toBe(6);
    for (const r of p.rows) {
      expect(r.unit).toBeGreaterThan(r.currentUnit);
      expect(r.lines).toBeNull(); // breakdown hidden → prospects wouldn't see lines
    }
    expect((await fx.directory.findBySlug('demo'))!.pricingConfig.marginMarkup).toBe(1.4);
    const bad = await b.send('POST', 'admin/settings/pricing/preview', { config: { ...config, marginMarkup: 9 }, quantity: 144, colorCount: 2 });
    expect(bad.status).toBe(422);
    expect((await bad.json()).error.errors.marginMarkup).toBeTruthy();
  });

  it('a save reaches storefront prices, switches the disclaimer and is audited', async () => {
    const { fx, email } = setup();
    const b = browser(fx, 'demo');
    await b.signIn(email, 'owner@demo.test');
    const before = await catalogUnits(b);
    const { config } = await load(b);
    config.marginMarkup = 1.8;
    config.rates.screen_print.screenChargePerColor = 3500;
    expect((await b.send('PUT', 'admin/settings/pricing', { config }, { 'x-csrf-token': 'nope' })).status).toBe(403);
    const r = await b.send('PUT', 'admin/settings/pricing', { config });
    expect(r.status).toBe(200);
    const after = await catalogUnits(b);
    for (const slug of Object.keys(before)) expect(after[slug]).toBeGreaterThan(before[slug]!);
    const cat = await (await b.call('catalog?qty=144')).json();
    expect(cat.disclaimer).toMatch(/this distributor's rate tables/);
    // What's stored is the validated rebuild, not the request body.
    const smuggled = { ...config, currency: 'EUR', injected: true, rates: { ...config.rates, extra: 1 } };
    expect((await b.send('PUT', 'admin/settings/pricing', { config: smuggled })).status).toBe(200);
    const stored = (await fx.directory.findBySlug('demo'))!.pricingConfig as unknown as Record<string, any>;
    expect(stored.currency).toBe('USD');
    expect('injected' in stored || 'extra' in stored.rates).toBe(false);
    const entry = (await fx.audit.recent(DEMO_TENANT_ID, 5)).find((e) => e.action === 'settings.pricing' && e.target !== 'no change')!;
    expect(entry.target).toBe('blank markup 40% → 80%; rates: Screen Printing');
  });

  it('the storefront never exposes cost or margin, and hides the breakdown when asked', async () => {
    const { fx, email } = setup();
    const b = browser(fx, 'demo');
    const items = async () => (await (await b.call('catalog?qty=144')).json()).items as { total: number; lines: { label: string; amount: number }[] | null }[];
    for (const i of await items()) {
      expect(i.lines!.map((l) => l.label).join(' | ')).not.toMatch(/Margin|Blanks/);
      expect(i.lines!.reduce((s, l) => s + l.amount, 0)).toBe(i.total);
    }
    await b.signIn(email, 'owner@demo.test');
    const { config } = await load(b);
    expect((await b.send('PUT', 'admin/settings/pricing', { config: { ...config, showItemizedToProspect: false } })).status).toBe(200);
    for (const i of await items()) expect(i.lines).toBeNull();
  });

  it('rejects bad values field by field and saves nothing', async () => {
    const { fx, email } = setup();
    const b = browser(fx, 'demo');
    await b.signIn(email, 'owner@demo.test');
    const { config } = await load(b);
    config.fees.ltmFee = 12.5;
    config.rates.screen_print.runByBreak[1].minQty = 5;
    const r = await b.send('PUT', 'admin/settings/pricing', { config });
    expect(r.status).toBe(422);
    expect(Object.keys((await r.json()).error.errors).sort()).toEqual(['fees.ltmFee', 'rates.screen_print.runByBreak.1.minQty']);
    expect((await fx.directory.findBySlug('demo'))!.pricingConfig.rates).toBeUndefined();
  });
});
