/**
 * Postgres implementations of the repository contracts (DATA_MODE=postgres).
 * Tenant-scoped reads/writes run inside withTenant(), so RLS — not these WHERE clauses — is the
 * isolation boundary; the explicit tenant filters are defence in depth.
 * Requires a live database: verified by the CI `integration` job, not by the offline suites.
 */
import { and, asc, desc, eq, gt, ilike, inArray, isNull, lt, lte, or, sql, type SQL } from 'drizzle-orm';
import { getDb, withTenant } from '@/core/db/tenant';
import * as s from '@/core/db/schema';
import type { TenantBranding, TenantDirectory, TenantRecord } from '@/server/tenancy/context';
import type { AdminAuthStore, AdminRole, AdminSession, AuditEntry, AuditRepo, TenantSettingsWriter } from '@/server/admin/types';
import type { CatalogProduct } from '@/features/catalog/catalog';
import type { DeliveryBrief, DeliveryRepo, DeliveryStatus, LeadDelivery, LeadEvent, LeadListQuery, LeadRecord, LeadRepo, LeadUpsert, LeadSource, LogoRecord, LogoRepo, ProductRepo } from './types';
import { decodeLeadCursor, encodeLeadCursor } from './types';
import type { ProspectSession, SessionStore } from '@/server/session';
import { SESSION_TTL_SEC } from '@/server/session';
import type { DecorationMethodKey, QuantityBreak, TenantPricingConfig } from '@/pricing/types';
import type { Plan } from '@/flags/registry';
import type { TemplateKind } from '@/imaging/templates';
import { PLACEHOLDER_TENANT_CONFIG } from '@/pricing/placeholder-rates';
import { DEFAULT_LEAD_SETTINGS, type LeadSettings } from '@/features/leads/rules';

/** tenant_settings.lead_routing holds LeadSettings; tolerate older/partial rows. */
function parseLeadSettings(v: unknown): LeadSettings {
  const o = (v ?? {}) as Partial<LeadSettings>;
  const gate = o.gate && ['off', 'soft', 'hard'].includes(o.gate.mode) ? o.gate : DEFAULT_LEAD_SETTINGS.gate;
  const routing =
    // Only sealed secrets are accepted (ADR 0008); anything else falls back to the inbox.
    o.routing?.provider === 'webhook' && typeof o.routing.url === 'string' && typeof o.routing.secretSealed === 'string'
      ? o.routing
      : DEFAULT_LEAD_SETTINGS.routing;
  return { gate, routing, ...(typeof o.contactName === 'string' ? { contactName: o.contactName } : {}) };
}

const TEMPLATE_KINDS: readonly TemplateKind[] = ['tee', 'polo', 'cap', 'tumbler', 'tote', 'journal'];

/** Tiny TTL cache: tenant config is read on every request but changes rarely. */
class Ttl<V> {
  private readonly m = new Map<string, { v: V; at: number }>();
  private readonly ms: number;
  constructor(ms: number) {
    this.ms = ms;
  }
  async get(k: string, load: () => Promise<V>): Promise<V> {
    const hit = this.m.get(k);
    if (hit && Date.now() - hit.at < this.ms) return hit.v;
    const v = await load();
    this.m.set(k, { v, at: Date.now() });
    return v;
  }
  clear() {
    this.m.clear();
  }
}

export class DrizzleTenantDirectory implements TenantDirectory, TenantSettingsWriter {
  private readonly cache = new Ttl<TenantRecord | null>(5_000);
  private readonly kills = new Ttl<ReadonlySet<string>>(15_000);

  findBySlug(slug: string) {
    return this.cache.get(`s:${slug}`, async () => {
      const row = (await getDb().select().from(s.tenants).where(eq(s.tenants.slug, slug)).limit(1))[0];
      return row ? this.hydrate(row) : null;
    });
  }

  findByDomain(domain: string) {
    return this.cache.get(`d:${domain}`, async () => {
      const row = (await getDb().select().from(s.tenants).where(eq(s.tenants.customDomain, domain)).limit(1))[0];
      return row ? this.hydrate(row) : null;
    });
  }

  async listSlugs() {
    const rows = await getDb().select({ slug: s.tenants.slug }).from(s.tenants);
    return rows.map((r) => r.slug);
  }

  globalKillSwitches() {
    return this.kills.get('k', async () => {
      const rows = await getDb().select({ key: s.featureFlags.key }).from(s.featureFlags).where(eq(s.featureFlags.globalKill, true));
      return new Set(rows.map((r) => r.key));
    });
  }

  /**
   * Settings writes go through the directory so it can drop its own cache. Other app instances
   * see the change within the cache TTL (5 s).
   */
  async updateBranding(tenantId: string, b: Omit<TenantBranding, 'logoUrl'>) {
    await withTenant(tenantId, (tx) =>
      tx
        .insert(s.tenantBranding)
        .values({ tenantId, displayName: b.displayName, primaryHex: b.primaryHex, secondaryHex: b.secondaryHex, fontFamily: b.fontFamily })
        .onConflictDoUpdate({
          target: s.tenantBranding.tenantId,
          set: { displayName: b.displayName, primaryHex: b.primaryHex, secondaryHex: b.secondaryHex, fontFamily: b.fontFamily },
        }),
    );
    this.cache.clear();
  }

  async updatePricingConfig(tenantId: string, c: TenantPricingConfig) {
    await withTenant(tenantId, (tx) =>
      tx
        .insert(s.tenantSettings)
        .values({ tenantId, pricingConfig: c, leadRouting: DEFAULT_LEAD_SETTINGS })
        .onConflictDoUpdate({ target: s.tenantSettings.tenantId, set: { pricingConfig: c } }),
    );
    this.cache.clear();
  }

  async updateLeadSettings(tenantId: string, ls: LeadSettings) {
    await withTenant(tenantId, (tx) =>
      tx
        .insert(s.tenantSettings)
        .values({ tenantId, pricingConfig: PLACEHOLDER_TENANT_CONFIG, leadRouting: ls })
        .onConflictDoUpdate({ target: s.tenantSettings.tenantId, set: { leadRouting: ls } }),
    );
    this.cache.clear();
  }

  private hydrate(t: typeof s.tenants.$inferSelect): Promise<TenantRecord> {
    return withTenant(t.id, async (tx) => {
      const [branding] = await tx.select().from(s.tenantBranding).where(eq(s.tenantBranding.tenantId, t.id));
      const [settings] = await tx.select().from(s.tenantSettings).where(eq(s.tenantSettings.tenantId, t.id));
      const overrides = await tx
        .select()
        .from(s.featureOverrides)
        .where(and(eq(s.featureOverrides.tenantId, t.id), eq(s.featureOverrides.scope, 'tenant')));
      const rec: TenantRecord = {
        id: t.id,
        slug: t.slug,
        name: t.name,
        plan: t.planKey as Plan,
        branding: {
          displayName: branding?.displayName ?? t.name,
          primaryHex: branding?.primaryHex ?? '#1F45C6',
          secondaryHex: branding?.secondaryHex ?? '#111827',
          fontFamily: branding?.fontFamily ?? 'Inter',
        },
        pricingConfig: (settings?.pricingConfig as TenantPricingConfig | undefined) ?? PLACEHOLDER_TENANT_CONFIG,
        flagOverrides: Object.fromEntries(overrides.map((o) => [o.flagKey, o.enabled])),
        leads: parseLeadSettings(settings?.leadRouting),
      };
      if (t.customDomain) rec.customDomain = t.customDomain;
      return rec;
    });
  }
}

export class DrizzleProductRepo implements ProductRepo {
  async list(tenantId: string): Promise<CatalogProduct[]> {
    return withTenant(tenantId, async (tx) => {
      const [prods, colors, compat] = await Promise.all([
        tx.select().from(s.products).where(eq(s.products.tenantId, tenantId)),
        tx.select().from(s.productColors).where(eq(s.productColors.tenantId, tenantId)),
        tx.select().from(s.decorationCompatibility).where(eq(s.decorationCompatibility.tenantId, tenantId)),
      ]);
      return prods
        .filter((p) => (TEMPLATE_KINDS as readonly string[]).includes(p.template))
        .map((p) => {
          const breaks = p.breaks as QuantityBreak[];
          return {
            slug: p.slug,
            template: p.template as TemplateKind,
            name: p.name,
            category: p.category,
            brand: p.brand ?? '',
            traits: { isApparel: p.isApparel, isHardGood: p.isHardGood, isPolyester: p.isPolyester, isEco: p.isEco },
            blankBase: breaks[0]?.blankUnitCost ?? 0,
            breaks,
            colors: colors.filter((c) => c.productId === p.id).map((c) => ({ name: c.name, hex: c.hex, isDark: c.isDark })),
            methods: compat
              .filter((c) => c.productId === p.id)
              .map((c) => ({ method: c.methodKey as DecorationMethodKey, location: c.location, w: c.imprintWidthIn, h: c.imprintHeightIn })),
          };
        });
    });
  }

  async get(tenantId: string, slug: string): Promise<CatalogProduct | null> {
    return (await this.list(tenantId)).find((p) => p.slug === slug) ?? null;
  }
}

type LogoRow = typeof s.logoAssets.$inferSelect;

function toRecord(r: LogoRow): LogoRecord {
  const a = r.analysis as Pick<LogoRecord, 'sourceSize' | 'recommendedMethods' | 'warnings'> & { sourceType: LogoRecord['sourceType'] };
  return {
    id: r.id,
    tenantId: r.tenantId,
    hash: r.hash,
    knockoutEnclosed: r.knockoutEnclosed,
    sourceType: a.sourceType,
    isVector: r.isVector,
    sourceSize: a.sourceSize,
    originalKey: r.storageKey,
    cleanKey: r.cleanKey,
    palette: r.palette as LogoRecord['palette'],
    background: r.background as LogoRecord['background'],
    recommendedMethods: a.recommendedMethods,
    warnings: a.warnings,
    needsReview: r.needsReview,
    createdAt: r.createdAt.toISOString(),
  };
}

export class DrizzleLogoRepo implements LogoRepo {
  async create(rec: LogoRecord): Promise<void> {
    await withTenant(rec.tenantId, (tx) =>
      tx.insert(s.logoAssets).values({
        id: rec.id,
        tenantId: rec.tenantId,
        storageKey: rec.originalKey,
        cleanKey: rec.cleanKey,
        contentType: rec.sourceType,
        bytes: 0,
        isVector: rec.isVector,
        knockoutEnclosed: rec.knockoutEnclosed,
        palette: rec.palette,
        background: rec.background,
        analysis: { sourceType: rec.sourceType, sourceSize: rec.sourceSize, recommendedMethods: rec.recommendedMethods, warnings: rec.warnings },
        needsReview: rec.needsReview,
        hash: rec.hash,
      }),
    );
  }

  async get(tenantId: string, id: string): Promise<LogoRecord | null> {
    const rows = await withTenant(tenantId, (tx) =>
      tx.select().from(s.logoAssets).where(and(eq(s.logoAssets.tenantId, tenantId), eq(s.logoAssets.id, id))).limit(1),
    );
    return rows[0] ? toRecord(rows[0]) : null;
  }

  async update(tenantId: string, id: string, patch: Pick<LogoRecord, 'needsReview' | 'warnings'>): Promise<LogoRecord | null> {
    return withTenant(tenantId, async (tx) => {
      const [row] = await tx.select().from(s.logoAssets).where(and(eq(s.logoAssets.tenantId, tenantId), eq(s.logoAssets.id, id))).limit(1);
      if (!row) return null;
      const analysis = { ...(row.analysis as Record<string, unknown>), warnings: patch.warnings };
      const [updated] = await tx
        .update(s.logoAssets)
        .set({ needsReview: patch.needsReview, analysis })
        .where(and(eq(s.logoAssets.tenantId, tenantId), eq(s.logoAssets.id, id)))
        .returning();
      return updated ? toRecord(updated) : null;
    });
  }

  async findByHash(tenantId: string, hash: string, knockout: boolean): Promise<LogoRecord | null> {
    const rows = await withTenant(tenantId, (tx) =>
      tx
        .select()
        .from(s.logoAssets)
        .where(and(eq(s.logoAssets.tenantId, tenantId), eq(s.logoAssets.hash, hash), eq(s.logoAssets.knockoutEnclosed, knockout)))
        .limit(1),
    );
    return rows[0] ? toRecord(rows[0]) : null;
  }
}

type LeadRow = typeof s.leads.$inferSelect;

function toLead(r: LeadRow): LeadRecord {
  const rec: LeadRecord = {
    id: r.id,
    tenantId: r.tenantId,
    email: r.email,
    marketingOptIn: r.marketingOptIn,
    sources: r.sources as LeadSource[],
    createdAt: r.createdAt.toISOString(),
    updatedAt: r.updatedAt.toISOString(),
  };
  if (r.name) rec.name = r.name;
  if (r.company) rec.company = r.company;
  if (r.phone) rec.phone = r.phone;
  if (r.consent) rec.consent = r.consent as LeadRecord['consent'] & object;
  return rec;
}

export class DrizzleLeadRepo implements LeadRepo {
  /**
   * Race-safe upsert on (tenant_id, email): two tabs submitting at once can't create two leads.
   * Consent only upgrades (false → true, stamping version + time); contact fields fill in.
   */
  async upsertByEmail(tenantId: string, input: LeadUpsert, now: Date) {
    return withTenant(tenantId, async (tx) => {
      const consent = input.marketingOptIn ? { version: input.consentVersion, at: now.toISOString() } : null;
      const [row] = await tx
        .insert(s.leads)
        .values({
          tenantId,
          email: input.email,
          name: input.name || null,
          company: input.company || null,
          phone: input.phone || null,
          marketingOptIn: input.marketingOptIn,
          consent,
          sources: [input.source],
          createdAt: now,
          updatedAt: now,
        })
        .onConflictDoUpdate({
          target: [s.leads.tenantId, s.leads.email],
          set: {
            name: sql`coalesce(excluded.name, ${s.leads.name})`,
            company: sql`coalesce(excluded.company, ${s.leads.company})`,
            phone: sql`coalesce(excluded.phone, ${s.leads.phone})`,
            consent: sql`case when ${s.leads.marketingOptIn} then ${s.leads.consent} else excluded.consent end`,
            marketingOptIn: sql`${s.leads.marketingOptIn} or excluded.marketing_opt_in`,
            sources: sql`case when ${s.leads.sources} @> excluded.sources then ${s.leads.sources} else ${s.leads.sources} || excluded.sources end`,
            updatedAt: now,
          },
        })
        .returning();
      // On conflict created_at keeps its original value, so equality with `now` means inserted.
      return { lead: toLead(row!), created: row!.createdAt.getTime() === now.getTime() };
    });
  }

  async get(tenantId: string, id: string) {
    const rows = await withTenant(tenantId, (tx) =>
      tx.select().from(s.leads).where(and(eq(s.leads.tenantId, tenantId), eq(s.leads.id, id))).limit(1),
    );
    return rows[0] ? toLead(rows[0]) : null;
  }

  async addEvent(e: LeadEvent) {
    await withTenant(e.tenantId, (tx) =>
      tx.insert(s.leadEvents).values({ id: e.id, tenantId: e.tenantId, leadId: e.leadId, kind: e.kind, payload: e.payload, createdAt: new Date(e.createdAt) }),
    );
  }

  async list(tenantId: string, q: LeadListQuery) {
    if (q.ids && q.ids.length === 0) return { items: [], nextCursor: null };
    const L = s.leads;
    const conds: SQL[] = [eq(L.tenantId, tenantId)];
    if (q.source) conds.push(sql`${L.sources} @> ${JSON.stringify([q.source])}::jsonb`);
    if (q.ids) conds.push(inArray(L.id, q.ids));
    if (q.search) {
      const pat = `%${q.search.replace(/[\\%_]/g, (c) => `\\${c}`)}%`;
      conds.push(or(ilike(L.email, pat), ilike(L.name, pat), ilike(L.company, pat))!);
    }
    const after = q.cursor ? decodeLeadCursor(q.cursor) : null;
    if (after) {
      const at = new Date(after.createdAt);
      conds.push(or(lt(L.createdAt, at), and(eq(L.createdAt, at), lt(L.id, after.id)))!);
    }
    const rows = await withTenant(tenantId, (tx) =>
      tx.select().from(L).where(and(...conds)).orderBy(desc(L.createdAt), desc(L.id)).limit(q.limit + 1),
    );
    const items = rows.slice(0, q.limit).map(toLead);
    return { items, nextCursor: rows.length > q.limit ? encodeLeadCursor(items[items.length - 1]!) : null };
  }

  async events(tenantId: string, leadId: string): Promise<LeadEvent[]> {
    const rows = await withTenant(tenantId, (tx) =>
      tx.select().from(s.leadEvents).where(and(eq(s.leadEvents.tenantId, tenantId), eq(s.leadEvents.leadId, leadId))),
    );
    return rows.map((r) => ({
      id: r.id,
      tenantId: r.tenantId,
      leadId: r.leadId,
      kind: r.kind as LeadEvent['kind'],
      payload: r.payload as Record<string, unknown>,
      createdAt: r.createdAt.toISOString(),
    }));
  }
}

export class DrizzleSessionStore implements SessionStore {
  async get(tenantId: string, id: string): Promise<ProspectSession | null> {
    const rows = await withTenant(tenantId, (tx) =>
      tx.select().from(s.prospectSessions).where(and(eq(s.prospectSessions.tenantId, tenantId), eq(s.prospectSessions.id, id))).limit(1),
    );
    const r = rows[0];
    if (!r || Date.now() - r.updatedAt.getTime() > SESSION_TTL_SEC * 1000) return null;
    const out: ProspectSession = { id: r.id, tenantId: r.tenantId, proofProducts: r.proofProducts as string[], createdAt: r.createdAt.toISOString() };
    if (r.leadId) out.leadId = r.leadId;
    if (r.email) out.email = r.email;
    return out;
  }

  async save(x: ProspectSession): Promise<void> {
    const now = new Date();
    await withTenant(x.tenantId, (tx) =>
      tx
        .insert(s.prospectSessions)
        .values({ id: x.id, tenantId: x.tenantId, leadId: x.leadId ?? null, email: x.email ?? null, proofProducts: x.proofProducts, createdAt: new Date(x.createdAt), updatedAt: now })
        .onConflictDoUpdate({
          target: s.prospectSessions.id,
          set: { leadId: x.leadId ?? null, email: x.email ?? null, proofProducts: x.proofProducts, updatedAt: now },
        }),
    );
  }
}

type DeliveryRow = typeof s.leadDeliveries.$inferSelect;
const toDelivery = (r: DeliveryRow): LeadDelivery => ({
  id: r.id,
  tenantId: r.tenantId,
  leadId: r.leadId,
  source: r.source as LeadSource,
  payload: r.payload as Record<string, unknown>,
  status: r.status as LeadDelivery['status'],
  attempts: r.attempts,
  nextAttemptAt: r.nextAttemptAt ? r.nextAttemptAt.toISOString() : null,
  ...(r.lastError ? { lastError: r.lastError } : {}),
  ...(r.routedTo ? { routedTo: r.routedTo } : {}),
  createdAt: r.createdAt.toISOString(),
  updatedAt: r.updatedAt.toISOString(),
});
const d = (iso: string | null | undefined) => (iso ? new Date(iso) : null);

export class DrizzleDeliveryRepo implements DeliveryRepo {
  async create(x: LeadDelivery) {
    await withTenant(x.tenantId, (tx) =>
      tx.insert(s.leadDeliveries).values({
        id: x.id,
        tenantId: x.tenantId,
        leadId: x.leadId,
        source: x.source,
        payload: x.payload,
        status: x.status,
        attempts: x.attempts,
        nextAttemptAt: d(x.nextAttemptAt),
        lastError: x.lastError ?? null,
        routedTo: x.routedTo ?? null,
        createdAt: new Date(x.createdAt),
        updatedAt: new Date(x.updatedAt),
      }),
    );
  }

  async get(tenantId: string, id: string) {
    const rows = await withTenant(tenantId, (tx) =>
      tx.select().from(s.leadDeliveries).where(and(eq(s.leadDeliveries.tenantId, tenantId), eq(s.leadDeliveries.id, id))).limit(1),
    );
    return rows[0] ? toDelivery(rows[0]) : null;
  }

  async update(tenantId: string, id: string, p: Partial<LeadDelivery>) {
    const set: Partial<typeof s.leadDeliveries.$inferInsert> = {};
    if (p.status !== undefined) set.status = p.status;
    if (p.attempts !== undefined) set.attempts = p.attempts;
    if (p.nextAttemptAt !== undefined) set.nextAttemptAt = d(p.nextAttemptAt);
    if (p.lastError !== undefined) set.lastError = p.lastError;
    if (p.routedTo !== undefined) set.routedTo = p.routedTo;
    if (p.payload !== undefined) set.payload = p.payload;
    set.updatedAt = p.updatedAt ? new Date(p.updatedAt) : new Date();
    await withTenant(tenantId, (tx) =>
      tx.update(s.leadDeliveries).set(set).where(and(eq(s.leadDeliveries.tenantId, tenantId), eq(s.leadDeliveries.id, id))),
    );
  }

  /** SKIP LOCKED: concurrent workers take disjoint rows instead of queueing behind each other. */
  async claimDue(tenantId: string, now: Date, leaseUntil: Date, limit: number) {
    return withTenant(tenantId, async (tx) => {
      const due = await tx
        .select({ id: s.leadDeliveries.id })
        .from(s.leadDeliveries)
        .where(
          and(
            eq(s.leadDeliveries.tenantId, tenantId),
            inArray(s.leadDeliveries.status, ['pending', 'failed']),
            lte(s.leadDeliveries.nextAttemptAt, now),
          ),
        )
        .orderBy(asc(s.leadDeliveries.nextAttemptAt))
        .limit(limit)
        .for('update', { skipLocked: true });
      if (due.length === 0) return [];
      const rows = await tx
        .update(s.leadDeliveries)
        .set({ nextAttemptAt: leaseUntil })
        .where(and(eq(s.leadDeliveries.tenantId, tenantId), inArray(s.leadDeliveries.id, due.map((r) => r.id))))
        .returning();
      return rows.map(toDelivery).sort((a, b) => (a.createdAt < b.createdAt ? -1 : 1));
    });
  }

  async statusesFor(tenantId: string, leadIds: string[]) {
    if (leadIds.length === 0) return {};
    const D = s.leadDeliveries;
    const rows = await withTenant(tenantId, (tx) =>
      tx.select({ leadId: D.leadId, status: D.status, routedTo: D.routedTo }).from(D).where(and(eq(D.tenantId, tenantId), inArray(D.leadId, leadIds))),
    );
    const out: Record<string, DeliveryBrief[]> = {};
    for (const r of rows) (out[r.leadId] ??= []).push({ status: r.status as DeliveryStatus, ...(r.routedTo ? { routedTo: r.routedTo } : {}) });
    return out;
  }

  async leadIdsWithStatus(tenantId: string, statuses: DeliveryStatus[], limit: number) {
    const D = s.leadDeliveries;
    const rows = await withTenant(tenantId, (tx) =>
      tx.selectDistinct({ leadId: D.leadId }).from(D).where(and(eq(D.tenantId, tenantId), inArray(D.status, statuses))).limit(limit),
    );
    return rows.map((r) => r.leadId);
  }

  async forLead(tenantId: string, leadId: string) {
    const rows = await withTenant(tenantId, (tx) =>
      tx
        .select()
        .from(s.leadDeliveries)
        .where(and(eq(s.leadDeliveries.tenantId, tenantId), eq(s.leadDeliveries.leadId, leadId)))
        .orderBy(asc(s.leadDeliveries.createdAt)),
    );
    return rows.map(toDelivery);
  }
}

export class DrizzleAdminAuthStore implements AdminAuthStore {
  async findUserByEmail(tenantId: string, email: string) {
    const [u] = await withTenant(tenantId, (tx) =>
      tx.select().from(s.users).where(and(eq(s.users.tenantId, tenantId), eq(s.users.email, email))).limit(1),
    );
    return u ? { id: u.id, tenantId: u.tenantId, email: u.email, role: u.role as AdminRole } : null;
  }

  async getUser(tenantId: string, id: string) {
    const [u] = await withTenant(tenantId, (tx) =>
      tx.select().from(s.users).where(and(eq(s.users.tenantId, tenantId), eq(s.users.id, id))).limit(1),
    );
    return u ? { id: u.id, tenantId: u.tenantId, email: u.email, role: u.role as AdminRole } : null;
  }

  async createLoginToken(t: { id: string; tenantId: string; userId: string; tokenHash: string; expiresAt: Date; createdAt: Date }) {
    await withTenant(t.tenantId, (tx) => tx.insert(s.adminLoginTokens).values(t));
  }

  /** One conditional UPDATE … RETURNING: two concurrent consumes can't both win. */
  async consumeLoginToken(tenantId: string, tokenHash: string, now: Date) {
    const T = s.adminLoginTokens;
    const rows = await withTenant(tenantId, (tx) =>
      tx
        .update(T)
        .set({ usedAt: now })
        .where(and(eq(T.tenantId, tenantId), eq(T.tokenHash, tokenHash), isNull(T.usedAt), gt(T.expiresAt, now)))
        .returning({ userId: T.userId }),
    );
    return rows[0]?.userId ?? null;
  }

  async createSession(x: AdminSession & { tokenHash: string; createdAt: Date }) {
    await withTenant(x.tenantId, (tx) =>
      tx.insert(s.adminSessions).values({
        id: x.id,
        tenantId: x.tenantId,
        userId: x.userId,
        tokenHash: x.tokenHash,
        csrfToken: x.csrfToken,
        createdAt: x.createdAt,
        expiresAt: new Date(x.expiresAt),
      }),
    );
  }

  async findSession(tenantId: string, tokenHash: string, now: Date) {
    const S = s.adminSessions;
    const [r] = await withTenant(tenantId, (tx) =>
      tx
        .select()
        .from(S)
        .where(and(eq(S.tenantId, tenantId), eq(S.tokenHash, tokenHash), isNull(S.revokedAt), gt(S.expiresAt, now)))
        .limit(1),
    );
    return r ? { id: r.id, tenantId: r.tenantId, userId: r.userId, csrfToken: r.csrfToken, expiresAt: r.expiresAt.toISOString() } : null;
  }

  async revokeSession(tenantId: string, id: string, now: Date) {
    await withTenant(tenantId, (tx) =>
      tx.update(s.adminSessions).set({ revokedAt: now }).where(and(eq(s.adminSessions.tenantId, tenantId), eq(s.adminSessions.id, id))),
    );
  }
}

export class DrizzleAuditRepo implements AuditRepo {
  async record(e: AuditEntry) {
    await withTenant(e.tenantId, (tx) =>
      tx.insert(s.auditLog).values({ tenantId: e.tenantId, actor: e.actor, action: e.action, target: e.target ?? null, at: new Date(e.at) }),
    );
  }
  async recent(tenantId: string, limit: number) {
    const rows = await withTenant(tenantId, (tx) =>
      tx.select().from(s.auditLog).where(eq(s.auditLog.tenantId, tenantId)).orderBy(desc(s.auditLog.at)).limit(limit),
    );
    return rows.map((r) => ({ tenantId: r.tenantId, actor: r.actor, action: r.action, ...(r.target ? { target: r.target } : {}), at: r.at.toISOString() }));
  }
}
