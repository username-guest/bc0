/** In-memory repositories + tenant directory (tests, offline dev server, demos). */
import type { TenantBranding, TenantDirectory, TenantRecord } from '@/server/tenancy/context';
import type { LeadSettings } from '@/features/leads/rules';
import type { TenantPricingConfig } from '@/pricing/types';
import type { AdminAuthStore, AdminSession, AdminUser, AuditEntry, AuditRepo, TenantSettingsWriter } from '@/server/admin/types';
import type { CatalogProduct } from '@/features/catalog/catalog';
import { randomUUID } from 'node:crypto';
import type { DeliveryBrief, DeliveryRepo, DeliveryStatus, LeadDelivery, LeadEvent, LeadListQuery, LeadRecord, LeadRepo, LeadUpsert, LogoRecord, LogoRepo, ProductRepo } from './types';
import { decodeLeadCursor, encodeLeadCursor } from './types';

export class MemoryLogoRepo implements LogoRepo {
  private readonly byTenant = new Map<string, Map<string, LogoRecord>>();
  async create(rec: LogoRecord): Promise<void> {
    let t = this.byTenant.get(rec.tenantId);
    if (!t) this.byTenant.set(rec.tenantId, (t = new Map()));
    t.set(rec.id, structuredClone(rec));
  }
  async get(tenantId: string, id: string): Promise<LogoRecord | null> {
    const r = this.byTenant.get(tenantId)?.get(id);
    return r ? structuredClone(r) : null;
  }
  async update(tenantId: string, id: string, patch: Pick<LogoRecord, 'needsReview' | 'warnings'>) {
    const r = this.byTenant.get(tenantId)?.get(id);
    if (!r) return null;
    Object.assign(r, patch);
    return structuredClone(r);
  }
  async findByHash(tenantId: string, hash: string, knockout: boolean): Promise<LogoRecord | null> {
    for (const r of this.byTenant.get(tenantId)?.values() ?? []) {
      if (r.hash === hash && r.knockoutEnclosed === knockout) return structuredClone(r);
    }
    return null;
  }
}

export class MemoryProductRepo implements ProductRepo {
  private readonly byTenant: Map<string, CatalogProduct[]>;
  constructor(seed: Record<string, CatalogProduct[]>) {
    this.byTenant = new Map(Object.entries(seed));
  }
  async list(tenantId: string): Promise<CatalogProduct[]> {
    return structuredClone(this.byTenant.get(tenantId) ?? []);
  }
  async get(tenantId: string, slug: string): Promise<CatalogProduct | null> {
    const p = (this.byTenant.get(tenantId) ?? []).find((x) => x.slug === slug);
    return p ? structuredClone(p) : null;
  }
}

export class MemoryTenantDirectory implements TenantDirectory, TenantSettingsWriter {
  private readonly tenants: TenantRecord[];
  private kills: Set<string>;
  constructor(tenants: TenantRecord[], kills: string[] = []) {
    this.tenants = tenants;
    this.kills = new Set(kills);
  }
  async findBySlug(slug: string) {
    return structuredClone(this.tenants.find((t) => t.slug === slug) ?? null);
  }
  async findByDomain(domain: string) {
    return structuredClone(this.tenants.find((t) => t.customDomain === domain) ?? null);
  }
  async listSlugs() {
    return this.tenants.map((t) => t.slug);
  }
  async globalKillSwitches() {
    return new Set(this.kills);
  }
  setKillSwitches(keys: string[]) {
    this.kills = new Set(keys);
  }
  async updateBranding(tenantId: string, b: Omit<TenantBranding, 'logoUrl'>) {
    const t = this.tenants.find((x) => x.id === tenantId);
    if (t) t.branding = { ...t.branding, ...structuredClone(b) };
  }
  async updatePricingConfig(tenantId: string, c: TenantPricingConfig) {
    const t = this.tenants.find((x) => x.id === tenantId);
    if (t) t.pricingConfig = structuredClone(c);
  }
  async updateLeadSettings(tenantId: string, ls: LeadSettings) {
    const t = this.tenants.find((x) => x.id === tenantId);
    if (t) t.leads = structuredClone(ls);
  }
}

export class MemoryLeadRepo implements LeadRepo {
  private readonly leads = new Map<string, LeadRecord[]>();
  private readonly evts = new Map<string, LeadEvent[]>();

  async upsertByEmail(tenantId: string, input: LeadUpsert, now: Date) {
    const list = this.leads.get(tenantId) ?? [];
    this.leads.set(tenantId, list);
    const at = now.toISOString();
    let lead = list.find((l) => l.email === input.email);
    const created = !lead;
    if (!lead) {
      lead = { id: randomUUID(), tenantId, email: input.email, marketingOptIn: false, sources: [], createdAt: at, updatedAt: at };
      list.push(lead);
    }
    if (input.name) lead.name = input.name;
    if (input.company) lead.company = input.company;
    if (input.phone) lead.phone = input.phone;
    if (input.marketingOptIn && !lead.marketingOptIn) {
      lead.marketingOptIn = true;
      lead.consent = { version: input.consentVersion, at };
    }
    if (!lead.sources.includes(input.source)) lead.sources.push(input.source);
    lead.updatedAt = at;
    return { lead: structuredClone(lead), created };
  }

  async get(tenantId: string, id: string) {
    const l = (this.leads.get(tenantId) ?? []).find((x) => x.id === id);
    return l ? structuredClone(l) : null;
  }

  async addEvent(e: LeadEvent) {
    const list = this.evts.get(e.tenantId) ?? [];
    list.push(structuredClone(e));
    this.evts.set(e.tenantId, list);
  }

  async events(tenantId: string, leadId: string) {
    return structuredClone((this.evts.get(tenantId) ?? []).filter((e) => e.leadId === leadId));
  }

  async list(tenantId: string, q: LeadListQuery) {
    const after = q.cursor ? decodeLeadCursor(q.cursor) : null;
    const needle = q.search?.toLowerCase();
    const ids = q.ids ? new Set(q.ids) : null;
    const rows = (this.leads.get(tenantId) ?? [])
      .filter((l) => !q.source || l.sources.includes(q.source))
      .filter((l) => !ids || ids.has(l.id))
      .filter((l) => !needle || [l.email, l.name, l.company].some((v) => v?.toLowerCase().includes(needle)))
      .sort((a, b) => (a.createdAt === b.createdAt ? b.id.localeCompare(a.id) : b.createdAt.localeCompare(a.createdAt)))
      .filter((l) => !after || l.createdAt < after.createdAt || (l.createdAt === after.createdAt && l.id < after.id));
    const items = rows.slice(0, q.limit);
    const more = rows.length > q.limit;
    return { items: structuredClone(items), nextCursor: more ? encodeLeadCursor(items[items.length - 1]!) : null };
  }

  /** Test helper: every lead for a tenant. */
  all(tenantId: string): LeadRecord[] {
    return structuredClone(this.leads.get(tenantId) ?? []);
  }
}

export class MemoryDeliveryRepo implements DeliveryRepo {
  private readonly rows = new Map<string, LeadDelivery>();

  async create(d: LeadDelivery) {
    this.rows.set(d.id, structuredClone(d));
  }
  async get(tenantId: string, id: string) {
    const d = this.rows.get(id);
    return d && d.tenantId === tenantId ? structuredClone(d) : null;
  }
  async update(tenantId: string, id: string, patch: Partial<LeadDelivery>) {
    const d = this.rows.get(id);
    if (!d || d.tenantId !== tenantId) return;
    Object.assign(d, structuredClone(patch));
  }
  async claimDue(tenantId: string, now: Date, leaseUntil: Date, limit: number) {
    const due = [...this.rows.values()]
      .filter(
        (d) =>
          d.tenantId === tenantId &&
          (d.status === 'pending' || d.status === 'failed') &&
          d.nextAttemptAt !== null &&
          d.nextAttemptAt <= now.toISOString(),
      )
      .sort((a, b) => a.nextAttemptAt!.localeCompare(b.nextAttemptAt!))
      .slice(0, limit);
    for (const d of due) d.nextAttemptAt = leaseUntil.toISOString();
    return structuredClone(due);
  }
  async statusesFor(tenantId: string, leadIds: string[]) {
    const want = new Set(leadIds);
    const out: Record<string, DeliveryBrief[]> = {};
    for (const d of this.rows.values())
      if (d.tenantId === tenantId && want.has(d.leadId)) (out[d.leadId] ??= []).push({ status: d.status, ...(d.routedTo ? { routedTo: d.routedTo } : {}) });
    return out;
  }
  async leadIdsWithStatus(tenantId: string, statuses: DeliveryStatus[], limit: number) {
    const ids = new Set<string>();
    for (const d of this.rows.values()) if (d.tenantId === tenantId && statuses.includes(d.status)) ids.add(d.leadId);
    return [...ids].slice(0, limit);
  }
  async forLead(tenantId: string, leadId: string) {
    return structuredClone(
      [...this.rows.values()].filter((d) => d.tenantId === tenantId && d.leadId === leadId).sort((a, b) => a.createdAt.localeCompare(b.createdAt)),
    );
  }
}

export class MemoryAdminAuthStore implements AdminAuthStore {
  private readonly users: AdminUser[];
  private readonly tokens = new Map<string, { tenantId: string; userId: string; tokenHash: string; expiresAt: number; usedAt: number | null }>();
  private readonly sessions = new Map<string, AdminSession & { tokenHash: string; revokedAt: number | null }>();
  constructor(users: AdminUser[] = []) {
    this.users = structuredClone(users);
  }
  async findUserByEmail(tenantId: string, email: string) {
    return structuredClone(this.users.find((u) => u.tenantId === tenantId && u.email === email) ?? null);
  }
  async getUser(tenantId: string, id: string) {
    return structuredClone(this.users.find((u) => u.tenantId === tenantId && u.id === id) ?? null);
  }
  async createLoginToken(t: { id: string; tenantId: string; userId: string; tokenHash: string; expiresAt: Date; createdAt: Date }) {
    this.tokens.set(t.id, { tenantId: t.tenantId, userId: t.userId, tokenHash: t.tokenHash, expiresAt: t.expiresAt.getTime(), usedAt: null });
  }
  async consumeLoginToken(tenantId: string, tokenHash: string, now: Date) {
    for (const t of this.tokens.values()) {
      if (t.tenantId !== tenantId || t.tokenHash !== tokenHash) continue;
      if (t.usedAt !== null || t.expiresAt <= now.getTime()) return null;
      t.usedAt = now.getTime(); // synchronous check-and-set: single use even under concurrency
      return t.userId;
    }
    return null;
  }
  async createSession(s: AdminSession & { tokenHash: string; createdAt: Date }) {
    const { createdAt: _createdAt, ...row } = s;
    this.sessions.set(s.id, { ...structuredClone(row), revokedAt: null });
  }
  async findSession(tenantId: string, tokenHash: string, now: Date) {
    for (const s of this.sessions.values()) {
      if (s.tenantId === tenantId && s.tokenHash === tokenHash && s.revokedAt === null && Date.parse(s.expiresAt) > now.getTime()) {
        return { id: s.id, tenantId: s.tenantId, userId: s.userId, csrfToken: s.csrfToken, expiresAt: s.expiresAt };
      }
    }
    return null;
  }
  async revokeSession(tenantId: string, id: string, now: Date) {
    const s = this.sessions.get(id);
    if (s && s.tenantId === tenantId) s.revokedAt = now.getTime();
  }
  async sweep(tenantId: string, c: { tokensBefore: Date; sessionsBefore: Date }) {
    let tokens = 0;
    let sessions = 0;
    const tb = c.tokensBefore.getTime();
    const sb = c.sessionsBefore.getTime();
    for (const [id, t] of this.tokens) {
      if (t.tenantId === tenantId && (t.expiresAt < tb || (t.usedAt !== null && t.usedAt < tb))) {
        this.tokens.delete(id);
        tokens++;
      }
    }
    for (const [id, s] of this.sessions) {
      if (s.tenantId === tenantId && (Date.parse(s.expiresAt) < sb || (s.revokedAt !== null && s.revokedAt < sb))) {
        this.sessions.delete(id);
        sessions++;
      }
    }
    return { tokens, sessions };
  }
  /** Test helper: live row counts. */
  counts() {
    return { tokens: this.tokens.size, sessions: this.sessions.size };
  }
}

export class MemoryAuditRepo implements AuditRepo {
  private readonly rows: AuditEntry[] = [];
  async record(e: AuditEntry) {
    this.rows.push(structuredClone(e));
  }
  async recent(tenantId: string, limit: number) {
    return structuredClone(this.rows.filter((r) => r.tenantId === tenantId).slice(-limit).reverse());
  }
}
