/**
 * Tenant admin contracts (ADR 0008). Everything here is tenant-scoped: every method takes the
 * tenant id and the Postgres implementations run inside withTenant (RLS).
 */
import type { LeadSettings } from '@/features/leads/rules';
import type { TenantBranding } from '@/server/tenancy/context';
import type { TenantPricingConfig } from '@/pricing/types';

export type AdminRole = 'tenant_owner' | 'tenant_admin';

export interface AdminUser {
  id: string;
  tenantId: string;
  email: string; // lower-cased
  role: AdminRole;
}

export interface AdminSession {
  id: string;
  tenantId: string;
  userId: string;
  csrfToken: string;
  expiresAt: string;
}

export interface AdminAuthStore {
  findUserByEmail(tenantId: string, email: string): Promise<AdminUser | null>;
  getUser(tenantId: string, id: string): Promise<AdminUser | null>;
  /** Stores only the SHA-256 of the token. */
  createLoginToken(t: { id: string; tenantId: string; userId: string; tokenHash: string; expiresAt: Date; createdAt: Date }): Promise<void>;
  /**
   * Single use, atomically: marks the token used and returns its user id, or null if it is
   * unknown, expired or already used. Two concurrent consumes can't both succeed.
   */
  consumeLoginToken(tenantId: string, tokenHash: string, now: Date): Promise<string | null>;
  createSession(s: AdminSession & { tokenHash: string; createdAt: Date }): Promise<void>;
  /** Live (unexpired, unrevoked) session for this token hash, else null. */
  findSession(tenantId: string, tokenHash: string, now: Date): Promise<AdminSession | null>;
  revokeSession(tenantId: string, id: string, now: Date): Promise<void>;
}

export interface TenantSettingsWriter {
  updateBranding(tenantId: string, b: Omit<TenantBranding, 'logoUrl'>): Promise<void>;
  updateLeadSettings(tenantId: string, s: LeadSettings): Promise<void>;
  updatePricingConfig(tenantId: string, c: TenantPricingConfig): Promise<void>;
}

export interface AuditEntry {
  tenantId: string;
  actor: string; // user id or 'system'
  action: string;
  target?: string;
  at: string;
}

export interface AuditRepo {
  record(e: AuditEntry): Promise<void>;
  recent(tenantId: string, limit: number): Promise<AuditEntry[]>;
}
