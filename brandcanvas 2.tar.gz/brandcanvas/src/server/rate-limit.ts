/**
 * Fixed-window rate limiter (§12 abuse protection for uploads and renders).
 * In-memory = per instance. For multi-instance deployments swap the store for Postgres/Redis
 * behind the same `RateLimiter` interface; callers don't change.
 */
export interface RateDecision {
  ok: boolean;
  remaining: number;
  retryAfterSec: number;
}

export interface RateLimiter {
  hit(key: string, now?: number): RateDecision;
}

export class FixedWindowLimiter implements RateLimiter {
  private readonly windows = new Map<string, { start: number; count: number }>();
  private readonly max: number;
  private readonly windowMs: number;

  constructor(max: number, windowMs: number) {
    this.max = max;
    this.windowMs = windowMs;
  }

  hit(key: string, now = Date.now()): RateDecision {
    let w = this.windows.get(key);
    if (!w || now - w.start >= this.windowMs) {
      w = { start: now, count: 0 };
      this.windows.set(key, w);
      if (this.windows.size > 50_000) this.sweep(now); // bound memory under key-spraying
    }
    w.count++;
    const ok = w.count <= this.max;
    return {
      ok,
      remaining: Math.max(0, this.max - w.count),
      retryAfterSec: ok ? 0 : Math.ceil((w.start + this.windowMs - now) / 1000),
    };
  }

  private sweep(now: number): void {
    for (const [k, w] of this.windows) if (now - w.start >= this.windowMs) this.windows.delete(k);
  }
}
