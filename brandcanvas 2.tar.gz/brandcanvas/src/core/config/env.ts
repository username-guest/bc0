import { z } from 'zod';

/**
 * Schema-validated environment (§12). Import ONLY from server code.
 * Fails fast at boot if anything required is missing or malformed.
 */
const EnvSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  BASE_DOMAIN: z.string().default('brandcanvas.app'),
  AUTH_SECRET: z.string().min(16).optional(),

  /** memory = seeded demo tenants, no Postgres (dev/demo); postgres = real, RLS-enforced data. */
  DATA_MODE: z.enum(['memory', 'postgres']).default('memory'),
  DATABASE_URL: z.string().url().optional(),
  APP_DB_ROLE: z.string().default('brandcanvas_app'),

  /** local = filesystem (dev / single node); s3 = S3-compatible (adapter pending, ADR 0006). */
  STORAGE_DRIVER: z.enum(['local', 'memory', 's3']).default('local'),
  LOCAL_STORAGE_DIR: z.string().default('.data/storage'),
  TRUST_PROXY: z.enum(['true', 'false']).default('false').transform((v) => v === 'true'),
  MAX_UPLOAD_MB: z.coerce.number().positive().max(50).default(10),
  UPLOAD_RATE_MAX: z.coerce.number().int().positive().default(20),
  PROOF_RATE_MAX: z.coerce.number().int().positive().default(240),
  LEAD_RATE_MAX: z.coerce.number().int().positive().default(10),
  /**
   * Keyring for tenant secrets at rest (ADR 0008): `id:base64(32 bytes)[,id:key…]`, first = current.
   * Generate a key with `openssl rand -base64 32`. Required in production.
   */
  SETTINGS_ENCRYPTION_KEYS: z.string().optional(),
  /** In-process retry of failed CRM deliveries (single node). Use `npm run jobs:deliveries` from cron otherwise. */
  DELIVERY_WORKER: z.enum(['inline', 'off']).default('inline'),
  /** Admin sign-in email (ADR 0008). `log` prints links to the server console (development only). */
  EMAIL_PROVIDER: z.enum(['log', 'resend']).default('log'),
  RESEND_API_KEY: z.string().optional(),
  EMAIL_FROM: z.string().default('BrandCanvas <no-reply@brandcanvas.app>'),
  /** Set for path-mode URLs in emails (dev: http://localhost:3000). Unset → tenant hosts. */
  PUBLIC_BASE_URL: z.string().url().optional(),
  ADMIN_SIGNIN_RATE_MAX: z.coerce.number().int().positive().default(10),
  DELIVERY_WORKER_INTERVAL_MS: z.coerce.number().int().min(5_000).default(30_000),

  STORAGE_ENDPOINT: z.string().url().optional(),
  STORAGE_BUCKET: z.string().default('brandcanvas-assets'),
  STORAGE_ACCESS_KEY: z.string().optional(),
  STORAGE_SECRET_KEY: z.string().optional(),

  IMAGE_PROVIDER: z.enum(['mock', 'fal', 'replicate', 'openai', 'gemini']).default('mock'),
  IMAGE_PROVIDER_API_KEY: z.string().optional(),
  BG_REMOVAL_PROVIDER: z.enum(['mock', 'local', 'remove_bg']).default('mock'),
  CRM_PROVIDER: z.enum(['mock', 'email', 'webhook', 'hubspot', 'salesforce']).default('mock'),

  RATE_LIMIT_WINDOW_MS: z.coerce.number().int().positive().default(60_000),
  RATE_LIMIT_MAX: z.coerce.number().int().positive().default(30),
})
  .refine((e) => e.DATA_MODE !== 'postgres' || !!e.DATABASE_URL, {
    message: 'DATABASE_URL is required when DATA_MODE=postgres',
    path: ['DATABASE_URL'],
  })
  .refine((e) => e.NODE_ENV !== 'production' || e.DATA_MODE === 'postgres', {
    message: 'DATA_MODE=memory is for development only',
    path: ['DATA_MODE'],
  })
  .refine((e) => e.NODE_ENV !== 'production' || !!e.AUTH_SECRET, {
    message: 'AUTH_SECRET is required in production',
    path: ['AUTH_SECRET'],
  })
  .refine((e) => e.NODE_ENV !== 'production' || !!e.SETTINGS_ENCRYPTION_KEYS, {
    message: 'SETTINGS_ENCRYPTION_KEYS is required in production',
    path: ['SETTINGS_ENCRYPTION_KEYS'],
  })
  .refine((e) => e.NODE_ENV !== 'production' || e.EMAIL_PROVIDER !== 'log', {
    message: 'EMAIL_PROVIDER=log prints sign-in links to the console; configure a real provider in production',
    path: ['EMAIL_PROVIDER'],
  })
  .refine((e) => e.EMAIL_PROVIDER !== 'resend' || !!e.RESEND_API_KEY, {
    message: 'RESEND_API_KEY is required when EMAIL_PROVIDER=resend',
    path: ['RESEND_API_KEY'],
  })
  .refine((e) => e.IMAGE_PROVIDER === 'mock' || !!e.IMAGE_PROVIDER_API_KEY, {
    message: 'IMAGE_PROVIDER_API_KEY is required unless IMAGE_PROVIDER=mock',
    path: ['IMAGE_PROVIDER_API_KEY'],
  });

export type Env = z.infer<typeof EnvSchema>;

/**
 * Validates an environment. A blank value (`STORAGE_ENDPOINT=` in .env) means "not set", so it
 * falls back to the default / optional instead of failing as "set to an invalid value".
 */
export function parseEnv(source: Record<string, string | undefined>): Env {
  const set = Object.fromEntries(Object.entries(source).filter(([, v]) => v !== undefined && v !== ''));
  return EnvSchema.parse(set);
}

let cached: Env | null = null;
export function getEnv(): Env {
  if (typeof window !== 'undefined') {
    throw new Error('getEnv() must not be called in the browser — no secrets in client bundles.');
  }
  if (!cached) cached = parseEnv(process.env);
  return cached;
}
