import { describe, it, expect } from 'vitest';
import { parseEnv } from '@/core/config/env';

// Every blank line in .env.example, exactly as a shell or dotenv loader delivers it.
const BLANKS = {
  STORAGE_ENDPOINT: '',
  STORAGE_ACCESS_KEY: '',
  STORAGE_SECRET_KEY: '',
  IMAGE_PROVIDER_API_KEY: '',
  SETTINGS_ENCRYPTION_KEYS: '',
  RESEND_API_KEY: '',
};

describe('parseEnv', () => {
  it('treats blank values as unset instead of invalid', () => {
    const env = parseEnv({ ...BLANKS, PUBLIC_BASE_URL: '', DATABASE_URL: '' });
    expect(env.STORAGE_ENDPOINT).toBeUndefined();
    expect(env.PUBLIC_BASE_URL).toBeUndefined();
    expect(env.RESEND_API_KEY).toBeUndefined();
  });

  it('falls back to defaults for blank numbers and switches', () => {
    const env = parseEnv({ MAX_UPLOAD_MB: '', TRUST_PROXY: '', DATA_MODE: '' });
    expect(env.MAX_UPLOAD_MB).toBe(10);
    expect(env.TRUST_PROXY).toBe(false);
    expect(env.DATA_MODE).toBe('memory');
  });

  it('still rejects a value that is set and malformed', () => {
    expect(() => parseEnv({ STORAGE_ENDPOINT: 'not a url' })).toThrow();
  });

  it('a blank key never satisfies a requirement', () => {
    expect(() => parseEnv({ EMAIL_PROVIDER: 'resend', RESEND_API_KEY: '' })).toThrow(/RESEND_API_KEY/);
    expect(() => parseEnv({ DATA_MODE: 'postgres', DATABASE_URL: '' })).toThrow(/DATABASE_URL/);
  });

  it('keeps real values', () => {
    const env = parseEnv({ STORAGE_ENDPOINT: 'https://s3.example.com', MAX_UPLOAD_MB: '25' });
    expect(env.STORAGE_ENDPOINT).toBe('https://s3.example.com');
    expect(env.MAX_UPLOAD_MB).toBe(25);
  });
});
