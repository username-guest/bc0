/**
 * Postgres-mode smoke test: drives the PRODUCTION build (`next start`, DATA_MODE=postgres, app role
 * under RLS) over real HTTP, and after each step checks the rows landed in Postgres.
 *
 * Prereqs: `npm run build`, `npm run db:setup`, and the app role able to log in (DATABASE_URL).
 *   DATABASE_URL=… MIGRATION_DATABASE_URL=… npm run smoke:pg
 *
 * Production refuses EMAIL_PROVIDER=log, so sign-in runs with the real `resend` provider and a
 * dummy key: the request must still answer 202 and store a hashed token. The test then plants a
 * token of its own (known secret, hashed as the app does) to exercise verify → session → CSRF.
 */
import { spawn, spawnSync } from 'node:child_process';
import { createHash, randomBytes } from 'node:crypto';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import pg from 'pg';
import { encodePng } from '@/imaging/png';
import { sampleLogo } from '@/imaging/fixtures';

const need = (k: string) => {
  const v = process.env[k];
  if (!v) throw new Error(`${k} is required`);
  return v;
};
const PORT = Number(process.env.SMOKE_PORT ?? 3100);
const base = `http://localhost:${PORT}`;
const started = new Date();
let failures = 0;
const check = (name: string, ok: boolean, detail = '') => {
  if (!ok) failures++;
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? `  (${detail})` : ''}`);
};
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

const db = new pg.Client({ connectionString: need('MIGRATION_DATABASE_URL') });
const one = async <T = Record<string, unknown>>(q: string, v: unknown[] = []) => (await db.query(q, v)).rows[0] as T | undefined;

const storage = await mkdtemp(path.join(tmpdir(), 'bc-pg-smoke-'));
const serverEnv = {
  ...process.env,
  PORT: String(PORT),
  DATA_MODE: 'postgres',
  DATABASE_URL: need('DATABASE_URL'),
  AUTH_SECRET: randomBytes(32).toString('base64url'),
  SETTINGS_ENCRYPTION_KEYS: `smoke:${randomBytes(32).toString('base64')}`,
  EMAIL_PROVIDER: 'resend',
  RESEND_API_KEY: 're_smoke_not_a_real_key',
  PUBLIC_BASE_URL: base,
  STORAGE_DRIVER: 'local',
  LOCAL_STORAGE_DIR: storage,
  DELIVERY_WORKER: 'off',
  NEXT_TELEMETRY_DISABLED: '1',
};
let serverLog = '';
const server = spawn(path.join('node_modules', '.bin', 'next'), ['start', '-p', String(PORT)], { env: serverEnv });
server.stdout.on('data', (b) => (serverLog += b));
server.stderr.on('data', (b) => (serverLog += b));

/** Browser-ish cookie jar + CSRF header. */
const jar = new Map<string, string>();
let csrf = '';
async function call(p: string, init: RequestInit = {}) {
  const headers = new Headers(init.headers);
  if (jar.size) headers.set('cookie', [...jar].map(([k, v]) => `${k}=${v}`).join('; '));
  if (csrf && init.method && init.method !== 'GET' && !headers.has('x-csrf-token')) headers.set('x-csrf-token', csrf);
  const res = await fetch(base + p, { ...init, headers, redirect: 'manual' });
  for (const sc of res.headers.getSetCookie()) {
    const [pair] = sc.split(';');
    const i = pair!.indexOf('=');
    const [k, v] = [pair!.slice(0, i), pair!.slice(i + 1)];
    if (v === '' || /max-age=0/i.test(sc)) jar.delete(k);
    else jar.set(k, v);
  }
  return res;
}
const send = (method: string, p: string, body: unknown, headers: Record<string, string> = {}) =>
  call(p, { method, headers: { 'content-type': 'application/json', ...headers }, body: JSON.stringify(body) });

try {
  await db.connect();
  const tenant = await one<{ id: string }>(`select id from tenants where slug = 'demo'`);
  if (!tenant) throw new Error('demo tenant missing — run npm run db:setup');
  const T = tenant.id;
  const api = '/api/t/demo';

  // Wait for the server.
  let up = false;
  for (let i = 0; i < 60 && !up; i++) {
    try {
      up = (await fetch(`${base}/t/demo`)).status > 0;
    } catch {
      await sleep(500);
    }
  }
  check('production server started (next start, DATA_MODE=postgres)', up);
  if (!up) throw new Error('server did not start');

  // 1. Storefront pages resolve the tenant from the database.
  const page = await fetch(`${base}/t/demo`);
  check('storefront renders for a seeded tenant', page.status === 200, String(page.status));
  const missing = await fetch(`${base}/t/no-such-tenant`);
  check('unknown tenant is a 404', missing.status === 404, String(missing.status));

  // 2. Logo upload → logo_assets.
  const form = new FormData();
  form.set('file', new Blob([encodePng(sampleLogo())], { type: 'image/png' }), 'logo.png');
  form.set('knockout', 'true');
  const upRes = await call(`${api}/logos`, { method: 'POST', body: form });
  const logo = ((await upRes.json()) as { logo?: { id: string; colorCount: number } }).logo;
  check('logo upload', upRes.status === 201 && !!logo, String(upRes.status));
  const logoRow = await one(`select 1 from logo_assets where id = $1 and tenant_id = $2`, [logo?.id, T]);
  check('  → logo_assets row, owned by the tenant', !!logoRow);

  // 3. Priced catalog from the tenant's products.
  type Item = { slug: string; unit: number; total: number; proofUrl: string | null; locked: boolean };
  const units = async () => {
    const r = await call(`${api}/catalog?logo=${logo?.id}&qty=144`);
    return { status: r.status, items: ((await r.json()) as { items?: Item[] }).items ?? [] };
  };
  const cat = await units();
  const priced = cat.items.every((i) => Number.isInteger(i.unit) && i.unit > 0 && Number.isInteger(i.total));
  check('catalog prices every product in integer cents', cat.status === 200 && cat.items.length > 0 && priced, `${cat.items.length} items`);

  // 4. A proof render → rendered_proofs.
  const open = cat.items.find((i) => i.proofUrl && !i.locked);
  const proof = open ? await call(open.proofUrl!) : null;
  check('proof renders as PNG', proof?.status === 200 && proof.headers.get('content-type') === 'image/png', String(proof?.status));
  const proofRow = await one(`select 1 from rendered_proofs where tenant_id = $1 and created_at >= $2`, [T, started]);
  check('  → rendered_proofs row', !!proofRow);

  // 5. Lead capture → leads + delivery outbox + session link.
  const email = `smoke+${Date.now()}@acme.test`;
  const lead = await send('POST', `${api}/leads/email`, { email, marketingOptIn: false, logoId: logo?.id, website: '', startedAt: Date.now() - 4000 });
  check('email-gate lead capture', lead.status === 201, String(lead.status));
  const leadRow = await one<{ id: string }>(`select id from leads where tenant_id = $1 and email = $2`, [T, email]);
  check('  → leads row', !!leadRow);
  const delivery = await one(`select status from lead_deliveries where tenant_id = $1 and lead_id = $2`, [T, leadRow?.id]);
  check('  → lead_deliveries outbox row', !!delivery, String((delivery as { status?: string } | undefined)?.status));
  const sess = await one(`select 1 from prospect_sessions where tenant_id = $1 and lead_id = $2`, [T, leadRow?.id]);
  check('  → prospect session linked to the lead', !!sess);

  // 6. Admin provisioning via the CLI (runs as the app role, under RLS).
  const adminEmail = 'owner@smoke.test';
  const add = spawnSync(path.join('node_modules', '.bin', 'tsx'), ['scripts/admin/add-admin.ts', 'demo', adminEmail, 'tenant_owner'], { env: process.env, encoding: 'utf8' });
  const user = await one<{ id: string }>(`select id from users where tenant_id = $1 and email = $2 and role = 'tenant_owner'`, [T, adminEmail]);
  check('npm run admin:add creates a tenant owner', add.status === 0 && !!user, add.stderr.trim().split('\n').pop() ?? '');

  // 7. Sign-in request → hashed single-use token (email itself fails: dummy Resend key).
  const signIn = await send('POST', `${api}/admin/sign-in`, { email: adminEmail });
  check('sign-in request answers 202 (no account enumeration)', signIn.status === 202, String(signIn.status));
  let token: { token_hash: string } | undefined;
  for (let i = 0; i < 20 && !token; i++) {
    token = await one(`select token_hash from admin_login_tokens where tenant_id = $1 and user_id = $2 and created_at >= $3`, [T, user?.id, started]);
    if (!token) await sleep(250);
  }
  check('  → admin_login_tokens row, stored as a SHA-256 hash', !!token && /^[0-9a-f]{64}$/.test(token.token_hash));

  // 8. Verify with a planted token (known secret) → session.
  const secret = randomBytes(32).toString('base64url');
  await db.query(
    `insert into admin_login_tokens (tenant_id, user_id, token_hash, expires_at) values ($1, $2, $3, now() + interval '10 minutes')`,
    [T, user?.id, createHash('sha256').update(secret, 'utf8').digest('hex')],
  );
  const verify = await send('POST', `${api}/admin/verify`, { token: secret });
  check('magic-link verify signs in', verify.status === 200, String(verify.status));
  const session = await one(`select 1 from admin_sessions where tenant_id = $1 and user_id = $2 and revoked_at is null`, [T, user?.id]);
  check('  → admin_sessions row', !!session);
  const replay = await send('POST', `${api}/admin/verify`, { token: secret });
  check('  a used link cannot be replayed', replay.status !== 200, String(replay.status));

  const me = await call(`${api}/admin/me`);
  csrf = ((await me.json()) as { csrfToken?: string }).csrfToken ?? '';
  check('admin/me returns a CSRF token', me.status === 200 && csrf.length > 0);
  const inbox = await call(`${api}/admin/leads`);
  check('lead inbox lists the captured lead', inbox.status === 200 && (await inbox.text()).includes(email));

  // 9. Pricing save → tenant_settings → storefront prices.
  const cfgRes = await call(`${api}/admin/settings/pricing`);
  const { config } = (await cfgRes.json()) as { config: Record<string, unknown> & { marginMarkup: number } };
  const markup = Math.round((config.marginMarkup + 0.5) * 100) / 100;
  const noCsrf = await send('PUT', `${api}/admin/settings/pricing`, { config: { ...config, marginMarkup: markup } }, { 'x-csrf-token': 'wrong' });
  check('pricing save without the CSRF token is refused', noCsrf.status === 403, String(noCsrf.status));
  const save = await send('PUT', `${api}/admin/settings/pricing`, { config: { ...config, marginMarkup: markup } });
  check('owner saves pricing', save.status === 200, String(save.status));
  const stored = await one<{ m: string }>(`select pricing_config->>'marginMarkup' as m from tenant_settings where tenant_id = $1`, [T]);
  check('  → tenant_settings.pricing_config updated', Number(stored?.m) === markup, `${stored?.m}`);
  const after = await units();
  const before = new Map(cat.items.map((i) => [i.slug, i.unit]));
  check('  → storefront prices rise for every product', after.items.length === cat.items.length && after.items.every((i) => i.unit > (before.get(i.slug) ?? Infinity)));
  const audit = await one(`select count(*)::int as n from audit_log where tenant_id = $1 and at >= $2`, [T, started]);
  check('  → audit_log records admin activity', ((audit as { n?: number } | undefined)?.n ?? 0) > 0, `${(audit as { n?: number } | undefined)?.n} rows`);

  // 10. Sign-out revokes the session server-side.
  const out = await send('POST', `${api}/admin/sign-out`, {});
  const revoked = await one(`select 1 from admin_sessions where tenant_id = $1 and user_id = $2 and revoked_at is not null`, [T, user?.id]);
  check('sign-out revokes the session in the database', out.status === 200 && !!revoked, String(out.status));
} catch (e) {
  failures++;
  console.log(`FAIL  ${(e as Error).message}`);
} finally {
  server.kill('SIGTERM');
  await db.end().catch(() => {});
  await rm(storage, { recursive: true, force: true });
}

if (failures) {
  console.log(`\n${failures} check(s) failed. Server log (last 40 lines):\n${serverLog.split('\n').slice(-40).join('\n')}`);
  process.exit(1);
}
console.log('\nPostgres smoke: all checks passed.');
process.exit(0);
