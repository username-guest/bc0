/**
 * Imported products must not collide with the tenant's other products (ADR 0017). Names and slugs
 * are unique per tenant; when a supplier product clashes with a product it doesn't own, its
 * supplier product id is appended to both, deterministically, so re-syncs land on the same row.
 */
import { slugify } from '@/integrations/promostandards/map';

export function importedIdentity(
  name: string,
  slug: string,
  supplierProductId: string,
  taken: { names: ReadonlySet<string>; slugs: ReadonlySet<string> },
): { name: string; slug: string } {
  const clash = taken.names.has(name.toLowerCase()) || taken.slugs.has(slug);
  if (!clash) return { name, slug };
  return { name: `${name} · ${supplierProductId}`, slug: `${slug.slice(0, 40)}-${slugify(supplierProductId)}`.slice(0, 80) };
}
