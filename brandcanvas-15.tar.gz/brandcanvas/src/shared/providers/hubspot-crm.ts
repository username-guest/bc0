/**
 * HubSpot as a lead destination (ADR 0019). Each distributor connects their own HubSpot account
 * with a private app access token (Settings → Where leads go), stored sealed like the webhook
 * secret (ADR 0008).
 *
 * Per lead: upsert the contact by email (no duplicates for returning prospects), then add a note
 * on that contact with the lead's details. The host is fixed (api.hubapi.com), so there is no
 * user-supplied address to guard. Failures are classified so the delivery outbox (ADR 0008) can
 * tell "try again later" (rate limit, HubSpot outage) from "a person must fix this" (token revoked,
 * missing scope), which the admin sees in the lead's timeline.
 */
import type { CrmProvider, LeadPayload } from './index';

export const HUBSPOT_API = 'https://api.hubapi.com';
/** Scopes the private app needs; shown in Settings and in errors. */
export const HUBSPOT_SCOPES = ['crm.objects.contacts.read', 'crm.objects.contacts.write'] as const;
/** HubSpot-defined association type: note → contact. */
const NOTE_TO_CONTACT = 202;

export type HubSpotFetch = (url: string, init: { method: string; headers: Record<string, string>; body?: string; signal?: AbortSignal }) => Promise<{
  status: number;
  headers: { get(name: string): string | null };
  text(): Promise<string>;
}>;

export class HubSpotError extends Error {
  /** permanent: the token or its scopes need fixing; retrying won't help. */
  readonly permanent: boolean;
  readonly status: number;
  constructor(message: string, status: number, permanent: boolean) {
    super(message);
    this.name = 'HubSpotError';
    this.status = status;
    this.permanent = permanent;
  }
}

export interface HubSpotAccount {
  portalId: string;
  /** e.g. app.hubspot.com, app-eu1.hubspot.com, for links to the contact. */
  uiDomain: string;
}

/** A private app token is "pat-<region>-<uuid>"; anything else is a typo or the wrong secret. */
export function hubspotTokenProblem(token: string): string | null {
  const t = token.trim();
  if (!t) return 'is required';
  if (t.length > 200) return 'is too long';
  if (!/^pat-[a-z0-9]+-[0-9a-f-]{20,}$/i.test(t)) return "doesn't look like a HubSpot private app token (it starts with pat-)";
  return null;
}

const esc = (s: string) => s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!);

const SOURCE_LABEL: Record<LeadPayload['source'], string> = {
  email_gate: 'Unlocked the catalog with their email',
  quote_request: 'Requested a quote',
  pdf_leavebehind: 'Downloaded a product sheet',
};

/** Flatten `details` for the note: nested values become "a › b: value" lines, capped. */
function detailLines(v: unknown, prefix = '', out: string[] = []): string[] {
  if (out.length >= 40) return out;
  if (v === null || v === undefined || v === '') return out;
  if (typeof v === 'object' && !Array.isArray(v)) {
    for (const [k, x] of Object.entries(v as Record<string, unknown>)) detailLines(x, prefix ? `${prefix} › ${k}` : k, out);
  } else if (Array.isArray(v)) {
    if (v.every((x) => typeof x !== 'object')) out.push(`${prefix}: ${v.join(', ')}`);
    else v.forEach((x, i) => detailLines(x, `${prefix} ${i + 1}`, out));
  } else out.push(`${prefix}: ${String(v)}`);
  return out;
}

/** The note body HubSpot shows on the contact (HTML; every value escaped). */
export function noteBody(lead: LeadPayload, storefront: string): string {
  const rows: string[] = [`<p><strong>New lead from ${esc(storefront)}</strong>: ${esc(SOURCE_LABEL[lead.source])}.</p>`];
  const li = (label: string, value: string) => `<li>${esc(label)}: ${esc(value)}</li>`;
  const items: string[] = [];
  if (lead.productInterest) items.push(li('Product', lead.productInterest));
  if (lead.contact?.company) items.push(li('Company', lead.contact.company));
  if (lead.contact?.phone) items.push(li('Phone', lead.contact.phone));
  items.push(li('Marketing emails', lead.marketingOptIn ? 'opted in' : 'not opted in'));
  for (const line of detailLines(lead.details)) {
    const i = line.indexOf(': ');
    items.push(li(line.slice(0, i), line.slice(i + 2).slice(0, 300)));
  }
  for (const [k, v] of Object.entries(lead.tracking ?? {}).slice(0, 10)) items.push(li(k, v.slice(0, 200)));
  if (lead.leadId) items.push(li('BrandCanvas lead', lead.leadId));
  rows.push(`<ul>${items.join('')}</ul>`);
  return rows.join('');
}

function splitName(name: string | undefined): { firstname?: string; lastname?: string } {
  const n = (name ?? '').trim().replace(/\s+/g, ' ');
  if (!n) return {};
  const i = n.indexOf(' ');
  return i === -1 ? { firstname: n } : { firstname: n.slice(0, i), lastname: n.slice(i + 1) };
}

export interface HubSpotOptions {
  fetch?: HubSpotFetch;
  timeoutMs?: number;
  /** Storefront name shown in the note ("New lead from Acme Promo"). */
  storefront: string;
  /** For the delivery's "routed to" line; learned when the token was saved. */
  portalId?: string;
}

export class HubSpotCrmProvider implements CrmProvider {
  private readonly token: string;
  private readonly fetch: HubSpotFetch;
  private readonly timeoutMs: number;
  private readonly storefront: string;
  private readonly portalId: string | undefined;

  constructor(token: string, opts: HubSpotOptions) {
    this.token = token.trim();
    this.fetch = opts.fetch ?? ((url, init) => fetch(url, init));
    this.timeoutMs = opts.timeoutMs ?? 8000;
    this.storefront = opts.storefront;
    this.portalId = opts.portalId;
  }

  private async call<T>(method: string, path: string, body?: unknown): Promise<T> {
    let res;
    try {
      res = await this.fetch(`${HUBSPOT_API}${path}`, {
        method,
        headers: { authorization: `Bearer ${this.token}`, 'content-type': 'application/json', accept: 'application/json' },
        ...(body === undefined ? {} : { body: JSON.stringify(body) }),
        signal: AbortSignal.timeout(this.timeoutMs),
      });
    } catch (e) {
      const timedOut = (e as Error).name === 'TimeoutError' || (e as Error).name === 'AbortError';
      throw new HubSpotError(timedOut ? `HubSpot did not answer within ${this.timeoutMs / 1000} s` : `Couldn't reach HubSpot (${(e as Error).message.slice(0, 120)})`, 0, false);
    }
    const text = await res.text();
    let json: unknown = null;
    try {
      json = text ? JSON.parse(text) : null;
    } catch {
      /* non-JSON error pages */
    }
    if (res.status >= 200 && res.status < 300) return json as T;
    const hsMessage = (json as { message?: string } | null)?.message?.slice(0, 200);
    if (res.status === 401) throw new HubSpotError('HubSpot rejected the access token. Create a new one in HubSpot and save it in Settings.', 401, true);
    if (res.status === 403) {
      throw new HubSpotError(`HubSpot refused: the private app is missing a permission (it needs ${HUBSPOT_SCOPES.join(', ')}).${hsMessage ? ` ${hsMessage}` : ''}`, 403, true);
    }
    if (res.status === 429) throw new HubSpotError(`HubSpot rate limit reached; will retry${res.headers.get('retry-after') ? ` after ${res.headers.get('retry-after')} s` : ''}.`, 429, false);
    if (res.status >= 500) throw new HubSpotError(`HubSpot had a problem (${res.status}); will retry.`, res.status, false);
    // Other 4xx: our request was refused (bad property, invalid email). A person should look.
    throw new HubSpotError(`HubSpot refused the lead (${res.status})${hsMessage ? `: ${hsMessage}` : ''}`, res.status, true);
  }

  /** Validates the token and returns the account it belongs to (Settings → Test / Save). */
  async account(): Promise<HubSpotAccount> {
    const r = await this.call<{ portalId?: number; uiDomain?: string }>('GET', '/account-info/v3/details');
    if (!r?.portalId) throw new HubSpotError("HubSpot didn't say which account this token belongs to.", 200, true);
    return { portalId: String(r.portalId), uiDomain: r.uiDomain ?? 'app.hubspot.com' };
  }

  async route(lead: LeadPayload): Promise<{ id: string; routedTo: string }> {
    const props: Record<string, string> = { email: lead.email, ...splitName(lead.contact?.name) };
    if (lead.contact?.company) props.company = lead.contact.company.slice(0, 200);
    if (lead.contact?.phone) props.phone = lead.contact.phone.slice(0, 50);
    // Upsert by email: a returning prospect updates their contact instead of duplicating it.
    const up = await this.call<{ results?: Array<{ id?: string }> }>('POST', '/crm/v3/objects/contacts/batch/upsert', {
      inputs: [{ idProperty: 'email', id: lead.email, properties: props }],
    });
    const contactId = up?.results?.[0]?.id;
    if (!contactId) throw new HubSpotError("HubSpot didn't return the contact it saved.", 200, false);
    const note = await this.call<{ id?: string }>('POST', '/crm/v3/objects/notes', {
      properties: { hs_timestamp: new Date().toISOString(), hs_note_body: noteBody(lead, this.storefront) },
      associations: [{ to: { id: contactId }, types: [{ associationCategory: 'HUBSPOT_DEFINED', associationTypeId: NOTE_TO_CONTACT }] }],
    });
    return { id: note?.id ?? contactId, routedTo: `HubSpot${this.portalId ? ` ${this.portalId}` : ''} contact ${contactId}` };
  }
}
