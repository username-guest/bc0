/** HubSpot lead routing (ADR 0019): provider behaviour, admin settings, delivery end to end. */
import { describe, it, expect } from 'vitest';
import { buildFixture, FREE_TENANT_ID } from './testing';
import { handleTenantApi } from './http/router';
import { DEMO_TENANT_ID } from '@/core/domain/demo-catalog';
import { MockEmailProvider } from '@/shared/providers/mocks';
import { HubSpotCrmProvider, HubSpotError, hubspotTokenProblem, noteBody, type HubSpotFetch } from '@/shared/providers/hubspot-crm';
import type { LeadPayload } from '@/shared/providers';

const TOKEN = 'pat-na1-11111111-2222-3333-4444-555555555555';
const OTHER = 'pat-eu1-aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';

/** A small stateful HubSpot: contacts keyed by email, notes, per-token accounts, scripted failures. */
function fakeHubSpot() {
  const accounts: Record<string, number> = { [TOKEN]: 4242, [OTHER]: 777 };
  const contacts = new Map<string, { id: string; properties: Record<string, string> }>();
  const notes: Array<{ id: string; body: string; contactId: string; assoc: unknown }> = [];
  const calls: Array<{ method: string; path: string; auth: string }> = [];
  let failNext: Array<number | 'network' | 'timeout' | 'pass'> = [];
  let revoked = new Set<string>();
  const res = (status: number, body: unknown, headers: Record<string, string> = {}) => ({
    status,
    headers: { get: (n: string) => headers[n.toLowerCase()] ?? null },
    text: async () => (body === undefined ? '' : JSON.stringify(body)),
  });
  const fetch: HubSpotFetch = async (url, init) => {
    const u = new URL(url);
    expect(u.origin).toBe('https://api.hubapi.com');
    const token = init.headers.authorization!.replace(/^Bearer /, '');
    calls.push({ method: init.method, path: u.pathname, auth: token });
    const f = failNext.shift();
    if (f === 'network') throw new TypeError('fetch failed');
    if (f === 'timeout') throw Object.assign(new Error('aborted'), { name: 'TimeoutError' });
    if (typeof f === 'number') return res(f, { message: `scripted ${f}` }, f === 429 ? { 'retry-after': '10' } : {});
    if (!(token in accounts) || revoked.has(token)) return res(401, { message: 'Authentication credentials not found.' });
    if (init.method === 'GET' && u.pathname === '/account-info/v3/details') return res(200, { portalId: accounts[token], uiDomain: 'app.hubspot.com' });
    const body = JSON.parse(init.body ?? '{}');
    if (u.pathname === '/crm/v3/objects/contacts/batch/upsert') {
      const input = body.inputs[0];
      expect(input.idProperty).toBe('email');
      const existing = contacts.get(input.id);
      const c = existing ?? { id: String(1000 + contacts.size), properties: {} };
      c.properties = { ...c.properties, ...input.properties };
      contacts.set(input.id, c);
      return res(200, { status: 'COMPLETE', results: [{ id: c.id, properties: c.properties, new: !existing }] });
    }
    if (u.pathname === '/crm/v3/objects/notes') {
      const n = { id: `n${notes.length + 1}`, body: body.properties.hs_note_body, contactId: body.associations[0].to.id, assoc: body.associations[0].types[0] };
      notes.push(n);
      return res(201, { id: n.id });
    }
    return res(404, { message: 'not found' });
  };
  return {
    fetch,
    contacts,
    notes,
    calls,
    fail: (...f: Array<number | 'network' | 'timeout' | 'pass'>) => (failNext = f),
    revoke: (t: string) => revoked.add(t),
    unrevoke: () => (revoked = new Set()),
  };
}

const lead = (over: Partial<LeadPayload> = {}): LeadPayload => ({
  tenantId: DEMO_TENANT_ID,
  email: 'pat@acme.test',
  source: 'quote_request',
  marketingOptIn: false,
  leadId: 'lead-1',
  ...over,
});

describe('HubSpot provider', () => {
  it('upserts the contact by email and adds a note associated to it', async () => {
    const hs = fakeHubSpot();
    const p = new HubSpotCrmProvider(TOKEN, { fetch: hs.fetch, storefront: 'Acme Promo', portalId: '4242' });
    const r = await p.route(lead({ contact: { name: 'Pat  Q. Doe', company: 'Acme', phone: '555-0100' }, productInterest: 'Classic Tee' }));
    expect(hs.contacts.get('pat@acme.test')!.properties).toEqual({ email: 'pat@acme.test', firstname: 'Pat', lastname: 'Q. Doe', company: 'Acme', phone: '555-0100' });
    expect(hs.notes).toHaveLength(1);
    expect(hs.notes[0]!.contactId).toBe('1000');
    expect(hs.notes[0]!.assoc).toEqual({ associationCategory: 'HUBSPOT_DEFINED', associationTypeId: 202 });
    expect(hs.notes[0]!.body).toContain('Acme Promo');
    expect(hs.notes[0]!.body).toContain('Requested a quote');
    expect(r).toEqual({ id: 'n1', routedTo: 'HubSpot 4242 contact 1000' });
  });

  it('a returning prospect updates the same contact instead of creating another', async () => {
    const hs = fakeHubSpot();
    const p = new HubSpotCrmProvider(TOKEN, { fetch: hs.fetch, storefront: 'Acme Promo' });
    await p.route(lead({ source: 'email_gate' }));
    await p.route(lead({ contact: { company: 'Acme Corp' } }));
    expect(hs.contacts.size).toBe(1);
    expect(hs.contacts.get('pat@acme.test')!.properties.company).toBe('Acme Corp');
    expect(hs.notes.map((n) => n.contactId)).toEqual(['1000', '1000']);
  });

  it('escapes everything a prospect typed and flattens quote details', () => {
    const body = noteBody(
      lead({ contact: { company: '<script>alert(1)</script>' }, details: { configuration: { color: 'Navy', sizes: ['S', 'M'] }, estimate: { total: 412.5 } }, tracking: { utm_source: '"x"' } }),
      'A & B <Promo>',
    );
    expect(body).not.toContain('<script>');
    expect(body).toContain('&lt;script&gt;');
    expect(body).toContain('A &amp; B &lt;Promo&gt;');
    expect(body).toContain('configuration › color: Navy');
    expect(body).toContain('configuration › sizes: S, M');
    expect(body).toContain('estimate › total: 412.5');
    expect(body).toContain('utm_source: &quot;x&quot;');
  });

  it('classifies failures: fix-it-yourself vs try-again-later', async () => {
    const hs = fakeHubSpot();
    const p = new HubSpotCrmProvider(TOKEN, { fetch: hs.fetch, storefront: 'S' });
    const err = async () => {
      try {
        await p.route(lead());
      } catch (e) {
        return e as HubSpotError;
      }
      throw new Error('expected a failure');
    };
    hs.fail(401);
    expect(await err()).toMatchObject({ permanent: true, message: expect.stringMatching(/rejected the access token/) });
    hs.fail(403);
    expect(await err()).toMatchObject({ permanent: true, message: expect.stringMatching(/crm\.objects\.contacts\.write/) });
    hs.fail(429);
    expect(await err()).toMatchObject({ permanent: false, message: expect.stringMatching(/rate limit.*10 s/) });
    hs.fail(503);
    expect(await err()).toMatchObject({ permanent: false, status: 503 });
    hs.fail('network');
    expect(await err()).toMatchObject({ permanent: false, message: expect.stringMatching(/Couldn't reach HubSpot/) });
    hs.fail('timeout');
    expect(await err()).toMatchObject({ permanent: false, message: expect.stringMatching(/did not answer within 8 s/) });
    hs.fail('pass', 400); // contact saved, note refused
    expect(await err()).toMatchObject({ permanent: true, status: 400 });
  });

  it('checks token shape before calling HubSpot', () => {
    expect(hubspotTokenProblem(TOKEN)).toBeNull();
    expect(hubspotTokenProblem(`  ${TOKEN} `)).toBeNull();
    expect(hubspotTokenProblem('')).toBe('is required');
    expect(hubspotTokenProblem('whsec_abc')).toMatch(/starts with pat-/);
    expect(hubspotTokenProblem('pat-na1-' + 'a'.repeat(300))).toBe('is too long');
  });
});

/* ------------------------------ admin + delivery ------------------------------ */

function setup() {
  const now = new Date('2026-09-01T12:00:00Z');
  const email = new MockEmailProvider();
  const hs = fakeHubSpot();
  const fx = buildFixture({ email, now: () => now, hubspotFetch: hs.fetch });
  return { fx, email, hs, clock: () => now };
}

function browser(fx: ReturnType<typeof buildFixture>, ref: string) {
  const jar = new Map<string, string>();
  let csrf = '';
  async function call(sub: string, init: RequestInit & { headers?: Record<string, string> } = {}) {
    const headers: Record<string, string> = { ...(init.headers ?? {}) };
    if (jar.size) headers.cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    if (csrf && init.method && init.method !== 'GET') headers['x-csrf-token'] = csrf;
    const res = await handleTenantApi(new Request(`http://localhost/api/t/${ref}/${sub}`, { ...init, headers }), ref, sub.split('?')[0]!.split('/'), {
      api: fx.api,
      admin: fx.admin,
      directory: fx.directory,
    });
    const set = res.headers.get('set-cookie');
    if (set) {
      const pair = set.split(';')[0]!;
      const i = pair.indexOf('=');
      if (pair.slice(i + 1)) jar.set(pair.slice(0, i), pair.slice(i + 1));
      else jar.delete(pair.slice(0, i));
    }
    return res;
  }
  const send = (method: string, sub: string, body: unknown) => call(sub, { method, headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
  return {
    call,
    send,
    async signIn(mail: MockEmailProvider, address: string) {
      await send('POST', 'admin/sign-in', { email: address });
      await fx.admin.settled();
      const token = /#token=([A-Za-z0-9_-]{43})/.exec(mail.sent[mail.sent.length - 1]!.text)![1];
      expect((await send('POST', 'admin/verify', { token })).status).toBe(200);
      csrf = (await (await call('admin/me')).json()).csrfToken;
    },
  };
}

const tenant = (fx: ReturnType<typeof buildFixture>, id: string) => fx.tenants.find((t) => t.id === id)!;

describe('HubSpot settings', () => {
  it('checks the token with HubSpot, stores it sealed and never returns it', async () => {
    const { fx, email, hs } = setup();
    const b = browser(fx, 'demo');
    await b.signIn(email, 'owner@demo.test');

    const bad = await b.send('PUT', 'admin/settings/routing', { provider: 'hubspot', token: 'not-a-token' });
    expect(bad.status).toBe(422);
    expect((await bad.json()).error.errors.token).toMatch(/pat-/);
    expect(hs.calls).toHaveLength(0); // rejected locally, HubSpot never asked

    hs.revoke(TOKEN);
    const rejected = await b.send('PUT', 'admin/settings/routing', { provider: 'hubspot', token: TOKEN });
    expect(rejected.status).toBe(422);
    expect((await rejected.json()).error.errors.token).toMatch(/rejected the access token/);
    expect(tenant(fx, DEMO_TENANT_ID).leads?.routing.provider ?? 'mock').toBe('mock');
    hs.unrevoke();

    const ok = await b.send('PUT', 'admin/settings/routing', { provider: 'hubspot', token: ` ${TOKEN} ` });
    expect(await ok.json()).toEqual({ ok: true, portalId: '4242' });
    const stored = tenant(fx, DEMO_TENANT_ID).leads!.routing;
    expect(stored).toMatchObject({ provider: 'hubspot', portalId: '4242', uiDomain: 'app.hubspot.com' });
    expect(JSON.stringify(stored)).not.toContain(TOKEN);
    expect(fx.secrets.open((stored as { tokenSealed: string }).tokenSealed, DEMO_TENANT_ID)).toBe(TOKEN);

    const settings = await (await b.call('admin/settings')).text();
    expect(settings).not.toContain(TOKEN);
    expect(JSON.parse(settings).routing).toEqual({ provider: 'hubspot', portalId: '4242', uiDomain: 'app.hubspot.com', hasToken: true });
    expect((await (await b.call('admin/me')).json()).routing).toBe('hubspot');
    const audit = await fx.audit.recent(DEMO_TENANT_ID, 5);
    expect(audit.find((e) => e.action === 'settings.routing')?.target).toBe('hubspot 4242');
    expect(JSON.stringify(audit)).not.toContain(TOKEN);
  });

  it('saving without a token keeps the connected one; a new token replaces it', async () => {
    const { fx, email } = setup();
    const b = browser(fx, 'demo');
    await b.signIn(email, 'owner@demo.test');
    expect((await b.send('PUT', 'admin/settings/routing', { provider: 'hubspot' })).status).toBe(422); // nothing to keep yet
    await b.send('PUT', 'admin/settings/routing', { provider: 'hubspot', token: TOKEN });
    const sealed = (tenant(fx, DEMO_TENANT_ID).leads!.routing as { tokenSealed: string }).tokenSealed;
    expect(await (await b.send('PUT', 'admin/settings/routing', { provider: 'hubspot' })).json()).toEqual({ ok: true, portalId: '4242' });
    expect((tenant(fx, DEMO_TENANT_ID).leads!.routing as { tokenSealed: string }).tokenSealed).toBe(sealed);
    await b.send('PUT', 'admin/settings/routing', { provider: 'hubspot', token: OTHER });
    expect(tenant(fx, DEMO_TENANT_ID).leads!.routing).toMatchObject({ portalId: '777' });
  });

  it('test connection confirms the token still works for the same account', async () => {
    const { fx, email, hs } = setup();
    const b = browser(fx, 'demo');
    await b.signIn(email, 'owner@demo.test');
    expect((await b.send('POST', 'admin/settings/routing/test', {})).status).toBe(409);
    await b.send('PUT', 'admin/settings/routing', { provider: 'hubspot', token: TOKEN });
    expect(await (await b.send('POST', 'admin/settings/routing/test', {})).json()).toEqual({ ok: true });
    hs.revoke(TOKEN);
    const r = await (await b.send('POST', 'admin/settings/routing/test', {})).json();
    expect(r.ok).toBe(false);
    expect(r.error).toMatch(/rejected the access token/);
    expect(hs.notes).toHaveLength(0); // a test never writes to the distributor's CRM
  });

  it('is owner-only and a Pro feature', async () => {
    const { fx, email, hs } = setup();
    const staff = browser(fx, 'demo');
    await staff.signIn(email, 'staff@demo.test');
    expect((await staff.send('PUT', 'admin/settings/routing', { provider: 'hubspot', token: TOKEN })).status).toBe(403);
    const free = browser(fx, 'basic');
    await free.signIn(email, 'owner@basic.test');
    const r = await free.send('PUT', 'admin/settings/routing', { provider: 'hubspot', token: TOKEN });
    expect(r.status).toBe(403);
    expect((await r.json()).error.code).toBe('feature_locked');
    expect(tenant(fx, FREE_TENANT_ID).leads?.routing.provider ?? 'mock').toBe('mock');
    expect(hs.calls).toHaveLength(0);
  });
});

describe('HubSpot delivery', () => {
  it('a captured lead becomes a HubSpot contact with a note', async () => {
    const { fx, email, hs, clock } = setup();
    const b = browser(fx, 'demo');
    await b.signIn(email, 'owner@demo.test');
    await b.send('PUT', 'admin/settings/routing', { provider: 'hubspot', token: TOKEN });
    expect((await b.send('POST', 'leads/email', { email: 'New.Buyer@Acme.test', startedAt: clock().getTime() - 5000, website: '' })).status).toBe(201);

    expect([...hs.contacts.keys()]).toEqual(['new.buyer@acme.test']);
    expect(hs.notes).toHaveLength(1);
    expect(hs.notes[0]!.body).toContain(tenant(fx, DEMO_TENANT_ID).branding.displayName.replace(/&/g, '&amp;'));
    const inbox = await (await b.call('admin/leads')).json();
    const detail = await (await b.call(`admin/leads/${inbox.items[0].id}`)).json();
    expect(detail.deliveries[0]).toMatchObject({ status: 'delivered' });
    expect(detail.events.map((e: { kind: string }) => e.kind)).toEqual(['captured', 'routed']);
    expect(JSON.stringify(detail)).toContain('HubSpot 4242 contact 1000');
    expect(fx.crm.received).toHaveLength(0); // the inbox-only mock was not used
  });

  it('a revoked token fails visibly, then the retry goes through once a new token is saved', async () => {
    const { fx, email, hs, clock } = setup();
    const b = browser(fx, 'demo');
    await b.signIn(email, 'owner@demo.test');
    await b.send('PUT', 'admin/settings/routing', { provider: 'hubspot', token: TOKEN });
    hs.revoke(TOKEN);
    await b.send('POST', 'leads/email', { email: 'late@acme.test', startedAt: clock().getTime() - 5000, website: '' });
    const inbox = await (await b.call('admin/leads?attention=1')).json();
    expect(inbox.items).toHaveLength(1);
    const detail = await (await b.call(`admin/leads/${inbox.items[0].id}`)).json();
    const d = detail.deliveries[0];
    expect(d).toMatchObject({ status: 'failed', retryable: true });
    expect(JSON.stringify(detail.events)).toMatch(/rejected the access token/);
    expect(hs.contacts.size).toBe(0);

    await b.send('PUT', 'admin/settings/routing', { provider: 'hubspot', token: OTHER });
    expect(await (await b.send('POST', `admin/deliveries/${d.id}/retry`, {})).json()).toMatchObject({ status: 'delivered' });
    expect(hs.calls.filter((c) => c.path === '/crm/v3/objects/notes').map((c) => c.auth)).toEqual([OTHER]);
  });

  it('after a downgrade, leads stay in the inbox and the HubSpot connection is kept for later', async () => {
    const { fx, email, hs, clock } = setup();
    const b = browser(fx, 'demo');
    await b.signIn(email, 'owner@demo.test');
    await b.send('PUT', 'admin/settings/routing', { provider: 'hubspot', token: TOKEN });
    tenant(fx, DEMO_TENANT_ID).flagOverrides = { crm_webhook_routing: false };
    await b.send('POST', 'leads/email', { email: 'after@acme.test', startedAt: clock().getTime() - 5000, website: '' });
    expect(hs.contacts.size).toBe(0);
    expect((await (await b.call('admin/me')).json()).routing).toBe('inbox');
    expect(tenant(fx, DEMO_TENANT_ID).leads!.routing.provider).toBe('hubspot');
  });
});
