# ADR 0019 — HubSpot as a lead destination

**Status:** Accepted · **Date:** 2026-09-25 · Builds on ADR 0007 (entitlements), 0008 (lead delivery, sealed secrets), 0018 (serverless)

## Context
Leads go to the BrandCanvas inbox and, on Pro, optionally to a signed webhook (ADR 0008). A webhook
reaches any CRM, but only through Zapier, Make or custom code. Many distributors use HubSpot's free
CRM, and the `CRM_PROVIDER` setting already listed `hubspot` without an implementation behind it.

## Decisions
1. **Each distributor connects its own HubSpot account with a private app access token**
   (`pat-…`), pasted in Settings → Where leads go. The private app needs
   `crm.objects.contacts.read` and `crm.objects.contacts.write`; the settings screen lists them.
   OAuth would need BrandCanvas registered as a public HubSpot app, which is deferred.
2. **The token is treated like the webhook secret:** sealed with the secret box bound to the tenant
   id, never returned to the browser, and never written to the audit log (which records
   `hubspot <account id>`). Saving without a token keeps the connected one; pasting a new one
   replaces it.
3. **A token is checked with HubSpot before it is saved** (`GET /account-info/v3/details`). A typo or
   revoked token is reported on the form, not in the first lead. The account id and UI domain are
   stored for display. "Test connection" repeats the check read-only and never writes to the CRM.
   It also reports when the token now belongs to a different HubSpot account.
4. **Per lead, two calls:** upsert the contact by email
   (`POST /crm/v3/objects/contacts/batch/upsert`, `idProperty: email`), then add a note on that
   contact (`POST /crm/v3/objects/notes`, association type 202). The upsert sets email, first/last
   name (split at the first space), company and phone when given. The note holds the storefront
   name, how the lead came in, the product, marketing opt-in, quote details and tracking
   parameters, with every value HTML-escaped. A returning prospect updates the same contact and
   gets another note. BrandCanvas does not set lifecycle stage, owner or subscription status; those
   stay under the distributor's control in HubSpot.
5. **Delivery is unchanged (ADR 0008).** HubSpot is one more `CrmProvider` behind the router,
   under the same Pro entitlement as the webhook (`crm_webhook_routing`). After a downgrade the
   connection is kept but leads stay in the inbox. Errors are written for the admin, for example
   "HubSpot rejected the access token…" or "missing a permission (it needs …)". Every failure
   follows the normal retry schedule, including a revoked token. Once a new token is saved, queued
   leads go through on the next retry, or right away with "Retry".
6. **The host is fixed** (`https://api.hubapi.com`), so the webhook's address guard isn't needed.
   Calls time out after 8 s.

## Consequences
- Distributors on HubSpot connect in about two minutes without Zapier. Other CRMs keep using the
  webhook.
- If the contact is saved but the note fails, the retry upserts the same contact again (no
  duplicate) and adds the note. If HubSpot saves a note but the response is lost, the retry can add
  a second note. That duplicate is harmless and visible.
- On the Vercel Hobby schedule (ADR 0018), retries run once a day, so after fixing a token an admin
  may want to press "Retry" on the affected leads.
- The error classification (`HubSpotError.permanent`) is recorded but not yet used to stop retries
  early. That's a possible later refinement.
- Tested against a fake HubSpot (contacts keyed by email, notes, scripted 401/403/429/5xx, network
  failures and timeouts). Not yet run against a live HubSpot account.
